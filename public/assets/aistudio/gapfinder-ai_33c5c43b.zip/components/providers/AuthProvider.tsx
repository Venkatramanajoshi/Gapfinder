"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { createClientSupabase, isSupabaseConfigured } from "@/lib/db/supabase-client";
import { User } from "@supabase/supabase-js";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  signup: (email: string, password: string) => Promise<{ error?: string }>;
  loginAsDemo: () => Promise<{ error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const supabase = createClientSupabase();

  useEffect(() => {
    if (!isSupabaseConfigured()) {
      if (typeof window !== "undefined") {
        const demoStored = localStorage.getItem("gapfinder_demo_user");
        if (demoStored) {
          try {
            setUser(JSON.parse(demoStored));
          } catch {
            setUser(null);
          }
        }
      }
      setLoading(false);
      return;
    }

    // 1. Initial active session check from cookie
    supabase.auth.getUser().then(({ data: { user: currentUser } }) => {
      setUser(currentUser);
      setLoading(false);
    }).catch(() => {
      setLoading(false);
    });

    // 2. Real-time auth state subscription
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [supabase]);

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      if (!isSupabaseConfigured()) {
        const demoUser = {
          id: "demo-user-123",
          email: email || "demo@gapfinder.app",
          user_metadata: { full_name: (email || "Demo").split("@")[0] },
          app_metadata: {},
          aud: "authenticated",
          created_at: new Date().toISOString(),
        } as unknown as User;

        if (typeof window !== "undefined") {
          localStorage.setItem("gapfinder_demo_user", JSON.stringify(demoUser));
          document.cookie = "gapfinder_demo_session=demo-user-123; path=/; max-age=604800";
        }
        setUser(demoUser);
        return {};
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) {
        return { error: error.message };
      }
      return {};
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, password: string) => {
    setLoading(true);
    try {
      if (!isSupabaseConfigured()) {
        const demoUser = {
          id: "demo-user-123",
          email: email || "demo@gapfinder.app",
          user_metadata: { full_name: (email || "Demo").split("@")[0] },
          app_metadata: {},
          aud: "authenticated",
          created_at: new Date().toISOString(),
        } as unknown as User;

        if (typeof window !== "undefined") {
          localStorage.setItem("gapfinder_demo_user", JSON.stringify(demoUser));
          document.cookie = "gapfinder_demo_session=demo-user-123; path=/; max-age=604800";
        }
        setUser(demoUser);
        return {};
      }

      const { error } = await supabase.auth.signUp({
        email,
        password,
      });
      if (error) {
        return { error: error.message };
      }
      return {};
    } finally {
      setLoading(false);
    }
  };

  const loginAsDemo = async () => {
    const demoUser = {
      id: "demo-user-123",
      email: "demo@gapfinder.app",
      user_metadata: { full_name: "Demo Student" },
      app_metadata: {},
      aud: "authenticated",
      created_at: new Date().toISOString(),
    } as unknown as User;

    if (!isSupabaseConfigured()) {
      if (typeof window !== "undefined") {
        localStorage.setItem("gapfinder_demo_user", JSON.stringify(demoUser));
        document.cookie = "gapfinder_demo_session=demo-user-123; path=/; max-age=604800";
      }
      setUser(demoUser);
      return {};
    }

    const res = await login("demo@gapfinder.app", "Demo@1234");
    if (res.error) {
      if (typeof window !== "undefined") {
        localStorage.setItem("gapfinder_demo_user", JSON.stringify(demoUser));
        document.cookie = "gapfinder_demo_session=demo-user-123; path=/; max-age=604800";
      }
      setUser(demoUser);
      return {};
    }
    return res;
  };

  const logout = async () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("gapfinder_demo_user");
      document.cookie = "gapfinder_demo_session=; path=/; max-age=0";
    }
    if (isSupabaseConfigured()) {
      try {
        await supabase.auth.signOut();
      } catch {
        // Ignore signout error
      }
    }
    setUser(null);
  };


  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        signup,
        loginAsDemo,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
