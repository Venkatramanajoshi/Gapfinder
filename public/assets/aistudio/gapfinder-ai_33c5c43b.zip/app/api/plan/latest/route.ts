import { NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import { demoStore } from "@/lib/db/demo-store";

export async function GET() {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!isSupabaseConfigured()) {
      const latestPlan = demoStore.revisionPlans[demoStore.revisionPlans.length - 1];
      const topicNameMap: Record<string, string> = {};
      demoStore.topics.forEach((t) => {
        topicNameMap[t.id] = t.name;
      });

      const latestGapsMap: Record<string, any> = {};
      demoStore.topicScores.forEach((s) => {
        if (!latestGapsMap[s.topic_id]) {
          let category: "weak" | "medium" | "strong" = "medium";
          if (s.score < 40) category = "weak";
          else if (s.score >= 75) category = "strong";

          latestGapsMap[s.topic_id] = {
            topic_id: s.topic_id,
            topic_name: topicNameMap[s.topic_id] || "Topic Area",
            score: Math.round(s.score),
            category,
            reason: s.reason,
          };
        }
      });

      return NextResponse.json({
        plan: latestPlan ? latestPlan.plan_json : null,
        daysAvailable: latestPlan?.days_available ?? 5,
        hoursPerDay: latestPlan?.hours_per_day ?? 3,
        gaps: Object.values(latestGapsMap),
      });
    }

    // 1. Fetch latest revision plan
    const { data: latestPlan } = await supabase
      .from("revision_plans")
      .select("plan_json, days_available, hours_per_day, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    // 2. Fetch latest topic scores
    const { data: scores } = await supabase
      .from("topic_scores")
      .select("topic_id, score, reason, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    // 3. Fetch topic names
    const { data: topics } = await supabase
      .from("topics")
      .select("id, name")
      .eq("user_id", user.id);

    const topicNameMap: Record<string, string> = {};
    (topics || []).forEach((t) => {
      topicNameMap[t.id] = t.name;
    });

    const latestGapsMap: Record<string, any> = {};
    (scores || []).forEach((s) => {
      if (!latestGapsMap[s.topic_id]) {
        let category: "weak" | "medium" | "strong" = "medium";
        if (s.score < 40) category = "weak";
        else if (s.score >= 75) category = "strong";

        latestGapsMap[s.topic_id] = {
          topic_id: s.topic_id,
          topic_name: topicNameMap[s.topic_id] || "Topic Area",
          score: Math.round(s.score),
          category,
          reason: s.reason,
        };
      }
    });

    return NextResponse.json({
      plan: latestPlan ? latestPlan.plan_json : (demoStore.revisionPlans[0]?.plan_json || null),
      daysAvailable: latestPlan?.days_available ?? 5,
      hoursPerDay: latestPlan?.hours_per_day ?? 3,
      gaps: Object.keys(latestGapsMap).length > 0 ? Object.values(latestGapsMap) : demoStore.topicScores,
    });
  } catch (error: any) {
    const latestPlan = demoStore.revisionPlans[demoStore.revisionPlans.length - 1];
    return NextResponse.json({
      plan: latestPlan ? latestPlan.plan_json : null,
      daysAvailable: 5,
      hoursPerDay: 3,
      gaps: demoStore.topicScores,
    });
  }
}
