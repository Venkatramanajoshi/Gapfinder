import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import { generateStructuredTextWithTimeout } from "@/lib/ai/gemini";
import { GapReportSchema, RevisionPlanSchema } from "@/lib/ai/schemas";
import { demoStore } from "@/lib/db/demo-store";

export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { daysAvailable = 5, hoursPerDay = 3, attemptId } = await req.json();

    let targetAttemptId = attemptId;
    let questions: any[] = [];
    let topics: any[] = [];

    if (!isSupabaseConfigured()) {
      if (!targetAttemptId && demoStore.attempts.length > 0) {
        targetAttemptId = demoStore.attempts[demoStore.attempts.length - 1].id;
      }
      questions = demoStore.questions.filter((q) => !targetAttemptId || q.attempt_id === targetAttemptId);
      if (questions.length === 0) questions = demoStore.questions;
      topics = demoStore.topics;
    } else {
      if (!targetAttemptId) {
        const { data: latestAtt } = await supabase
          .from("quiz_attempts")
          .select("id")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .single();
        targetAttemptId = latestAtt?.id;
      }

      if (targetAttemptId) {
        const { data: dbQ } = await supabase
          .from("quiz_questions")
          .select("topic_id, is_correct, question, user_answer, correct_answer")
          .eq("attempt_id", targetAttemptId);
        questions = dbQ || [];
      }

      if (questions.length === 0) {
        questions = demoStore.questions;
      }

      const topicIds = Array.from(new Set(questions.map((q) => q.topic_id)));
      const { data: dbT } = await supabase
        .from("topics")
        .select("id, name")
        .in("id", topicIds);
      topics = dbT || demoStore.topics;
    }

    const topicNameMap: Record<string, string> = {};
    (topics || []).forEach((t) => {
      topicNameMap[t.id] = t.name;
    });

    // 3. Compute per-topic scores in code: Strong >= 75%, Medium 40-74%, Weak < 40%
    const topicStats: Record<string, { total: number; correct: number; mistakes: string[] }> = {};
    questions.forEach((q) => {
      if (!topicStats[q.topic_id]) {
        topicStats[q.topic_id] = { total: 0, correct: 0, mistakes: [] };
      }
      topicStats[q.topic_id].total += 1;
      if (q.is_correct) {
        topicStats[q.topic_id].correct += 1;
      } else {
        topicStats[q.topic_id].mistakes.push(
          `Question: "${q.question}" | Chosen: "${q.user_answer}" | Correct: "${q.correct_answer}"`
        );
      }
    });

    const computedGaps = Object.entries(topicStats).map(([topicId, stats]) => {
      const score = Math.round((stats.correct / stats.total) * 100);
      let category: "weak" | "medium" | "strong" = "medium";
      if (score < 40) category = "weak";
      else if (score >= 75) category = "strong";

      return {
        topic_id: topicId,
        topic_name: topicNameMap[topicId] || "Core Topic",
        score,
        category,
        mistakes: stats.mistakes,
      };
    });

    // Ask LLM to generate one-line reasons if API key is set
    let parsedGaps: any[] = [];
    if (process.env.GEMINI_API_KEY) {
      try {
        const reasonPrompt = `
Generate a concise one-line academic diagnosis for each tested topic based on the student's mistakes:
${JSON.stringify(computedGaps, null, 2)}
Return strictly JSON matching:
{
  "topicGaps": [
    { "topic_id": "topicId", "topic_name": "topicName", "score": 0, "category": "weak", "reason": "One concise sentence" }
  ]
}
`;
        const rawJson = await generateStructuredTextWithTimeout(reasonPrompt, undefined, 15000);
        const parsed = GapReportSchema.parse(JSON.parse(rawJson));
        parsedGaps = parsed.topicGaps;
      } catch (e) {
        // Fallback
      }
    }

    const finalGaps = computedGaps.map((cg) => {
      const match = parsedGaps.find((p) => p.topic_id === cg.topic_id);
      let reason = match?.reason;
      if (!reason) {
        if (cg.category === "weak") {
          reason = `Fundamental conceptual gap identified in ${cg.topic_name} based on tested problem answers.`;
        } else if (cg.category === "medium") {
          reason = `Demonstrates good understanding of ${cg.topic_name}, but missed edge-case questions.`;
        } else {
          reason = `Flawless grasp and mastery demonstrated in ${cg.topic_name}.`;
        }
      }
      return {
        ...cg,
        reason,
      };
    });

    // 6. Generate revision schedule allocating 60% weak, 30% medium, 10% strong
    let planSchedule: any[] = [];
    if (process.env.GEMINI_API_KEY) {
      const planPrompt = `
Create an optimal revision plan given:
Days available: ${daysAvailable}
Hours per day: ${hoursPerDay}

Student Topic Diagnostics:
${JSON.stringify(finalGaps, null, 2)}

Prioritization Rules:
- Weak topics MUST receive top priority and 60% of total schedule time.
- Medium topics receive 30% of total time.
- Strong topics receive light review (10%).

Return strictly JSON matching:
{
  "schedule": [
    {
      "day": 1,
      "theme": "Theme title",
      "allocated_hours": ${hoursPerDay},
      "tasks": [
        {
          "topic_name": "Topic Name",
          "category": "weak",
          "activity": "Specific practice exercise",
          "duration_minutes": 60
        }
      ]
    }
  ]
}
`;
      try {
        const planRaw = await generateStructuredTextWithTimeout(planPrompt, undefined, 20000);
        const parsedPlan = RevisionPlanSchema.parse(JSON.parse(planRaw));
        planSchedule = parsedPlan.schedule;
      } catch (e) {
        // Fallback
      }
    }

    if (planSchedule.length === 0) {
      const weak = finalGaps.filter((g) => g.category === "weak");
      const med = finalGaps.filter((g) => g.category === "medium");
      const strong = finalGaps.filter((g) => g.category === "strong");

      for (let day = 1; day <= daysAvailable; day++) {
        const tasks: any[] = [];
        let theme = "Targeted Remediation & Active Practice";

        if (day <= Math.ceil(daysAvailable * 0.6) && weak.length > 0) {
          const targetWeak = weak[(day - 1) % weak.length];
          theme = `High-Priority Remediation: ${targetWeak.topic_name}`;
          tasks.push({
            topic_name: targetWeak.topic_name,
            category: "weak",
            activity: `Trace 3 example problems and re-read lecture notes.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.65),
          });
          if (med.length > 0) {
            tasks.push({
              topic_name: med[0].topic_name,
              category: "medium",
              activity: `Concept drill on boundary edge-cases.`,
              duration_minutes: Math.round(hoursPerDay * 60 * 0.35),
            });
          }
        } else if (day < daysAvailable && med.length > 0) {
          theme = "Medium Topic Reinforcement & Mixed Practice";
          tasks.push({
            topic_name: med[0].topic_name,
            category: "medium",
            activity: `Practice timed questions and review error logs.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.7),
          });
          if (strong.length > 0) {
            tasks.push({
              topic_name: strong[0].topic_name,
              category: "strong",
              activity: `Speed review of strong topic invariants.`,
              duration_minutes: Math.round(hoursPerDay * 60 * 0.3),
            });
          }
        } else {
          theme = "Comprehensive Simulation & Readiness Check";
          tasks.push({
            topic_name: "Mock Assessment",
            category: "weak",
            activity: `Retake GapFinder diagnostic quiz to verify 0 weak topics remaining.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.5),
          });
          tasks.push({
            topic_name: "Explain-This-Topic Consultation",
            category: "medium",
            activity: `Consult Grounded Assistant on any lingering doubts.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.5),
          });
        }

        planSchedule.push({
          day,
          theme,
          allocated_hours: hoursPerDay,
          tasks,
        });
      }
    }

    if (!isSupabaseConfigured()) {
      demoStore.revisionPlans.push({
        id: `plan-${Date.now()}`,
        user_id: user.id,
        days_available: daysAvailable,
        hours_per_day: hoursPerDay,
        plan_json: planSchedule,
        created_at: new Date().toISOString(),
      });
    } else {
      await supabase.from("revision_plans").insert({
        user_id: user.id,
        days_available: daysAvailable,
        hours_per_day: hoursPerDay,
        plan_json: planSchedule,
      });
    }

    return NextResponse.json({
      success: true,
      plan: planSchedule,
      gaps: finalGaps,
      attemptId: targetAttemptId,
    });
  } catch (error: any) {
    console.error("Plan generate error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
