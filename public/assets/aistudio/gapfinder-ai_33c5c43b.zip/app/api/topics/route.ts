import { NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import { demoStore } from "@/lib/db/demo-store";

export async function GET() {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!isSupabaseConfigured()) {
      const topics = demoStore.topics;
      const scores = demoStore.topicScores;
      const chunks = demoStore.chunks;

      const latestScoreByTopic: Record<string, any> = {};
      scores.forEach((s) => {
        let category = "medium";
        if (s.score >= 75) category = "strong";
        else if (s.score < 40) category = "weak";
        latestScoreByTopic[s.topic_id] = { ...s, category };
      });

      const chunkCounts: Record<string, number> = {};
      chunks.forEach((c) => {
        if (c.topic_id) {
          chunkCounts[c.topic_id] = (chunkCounts[c.topic_id] || 0) + 1;
        }
      });

      const parents = topics.filter((t) => !t.parent_id);
      const hierarchy = parents.map((p) => {
        const subtopics = topics
          .filter((t) => t.parent_id === p.id)
          .map((sub) => {
            const scoreItem = latestScoreByTopic[sub.id];
            return {
              ...sub,
              score: scoreItem ? Math.round(scoreItem.score) : null,
              category: scoreItem ? scoreItem.category : "unscored",
              reason: scoreItem ? scoreItem.reason : null,
              chunkCount: chunkCounts[sub.id] || 1,
            };
          });

        const parentScoreItem = latestScoreByTopic[p.id];
        const parentChunks =
          (chunkCounts[p.id] || 0) +
          subtopics.reduce((acc, st) => acc + (st.chunkCount || 0), 0);

        return {
          ...p,
          score: parentScoreItem ? Math.round(parentScoreItem.score) : null,
          category: parentScoreItem ? parentScoreItem.category : "unscored",
          chunkCount: parentChunks || 2,
          subtopics,
        };
      });

      return NextResponse.json({
        topics: hierarchy,
        rawCount: topics.length,
      });
    }

    // 1. Fetch user topics
    const { data: topics, error: topicErr } = await supabase
      .from("topics")
      .select("id, name, parent_id, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true });

    if (topicErr) throw topicErr;

    // 2. Fetch latest topic scores
    const { data: scores, error: scoreErr } = await supabase
      .from("topic_scores")
      .select("topic_id, score, category, reason, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (scoreErr) throw scoreErr;

    // Map unique latest score per topic
    const latestScoreByTopic: Record<string, any> = {};
    (scores || []).forEach((s) => {
      if (!latestScoreByTopic[s.topic_id]) {
        latestScoreByTopic[s.topic_id] = s;
      }
    });

    // 3. Fetch chunk counts per topic
    const { data: chunks, error: chunkErr } = await supabase
      .from("chunks")
      .select("topic_id")
      .eq("user_id", user.id);

    if (chunkErr) throw chunkErr;

    const chunkCounts: Record<string, number> = {};
    (chunks || []).forEach((c) => {
      if (c.topic_id) {
        chunkCounts[c.topic_id] = (chunkCounts[c.topic_id] || 0) + 1;
      }
    });

    // 4. Assemble hierarchy
    const parents = (topics || []).filter((t) => !t.parent_id);
    const hierarchy = parents.map((p) => {
      const subtopics = (topics || [])
        .filter((t) => t.parent_id === p.id)
        .map((sub) => {
          const scoreItem = latestScoreByTopic[sub.id];
          return {
            ...sub,
            score: scoreItem ? Math.round(scoreItem.score) : null,
            category: scoreItem ? scoreItem.category : "unscored",
            reason: scoreItem ? scoreItem.reason : null,
            chunkCount: chunkCounts[sub.id] || 0,
          };
        });

      const parentScoreItem = latestScoreByTopic[p.id];
      const parentChunks =
        (chunkCounts[p.id] || 0) +
        subtopics.reduce((acc, st) => acc + (st.chunkCount || 0), 0);

      return {
        ...p,
        score: parentScoreItem ? Math.round(parentScoreItem.score) : null,
        category: parentScoreItem ? parentScoreItem.category : "unscored",
        chunkCount: parentChunks,
        subtopics,
      };
    });

    return NextResponse.json({
      topics: hierarchy,
      rawCount: (topics || []).length,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

