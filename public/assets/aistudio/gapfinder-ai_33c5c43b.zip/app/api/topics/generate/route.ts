import { NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import {
  generateStructuredTextWithTimeout,
  generateBatchEmbeddings,
} from "@/lib/ai/gemini";
import { TopicTreeSchema } from "@/lib/ai/schemas";
import { demoStore } from "@/lib/db/demo-store";

export const maxDuration = 60;

export async function POST() {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    let chunks: any[] = [];

    if (!isSupabaseConfigured()) {
      chunks = demoStore.chunks;
    } else {
      let { data: dbChunks, error: chunkErr } = await supabase
        .from("chunks")
        .select("id, content, documents!inner(type)")
        .eq("user_id", user.id)
        .eq("documents.type", "syllabus")
        .limit(12);

      if (chunkErr || !dbChunks || dbChunks.length === 0) {
        const fallback = await supabase
          .from("chunks")
          .select("id, content")
          .eq("user_id", user.id)
          .limit(10);
        chunks = (fallback.data as any) || [];
      } else {
        chunks = dbChunks;
      }
    }

    if (!chunks || chunks.length === 0) {
      chunks = demoStore.chunks;
    }

    const contextText = chunks.map((c) => c.content).join("\n\n");

    const prompt = `
Extract a structured academic hierarchy from this course material.
Group into 3 to 6 major topics, each with 2 to 4 key subtopics.
Return strictly JSON matching this structure:
{
  "topics": [
    { "name": "Topic Name", "subtopics": ["Subtopic A", "Subtopic B"] }
  ]
}

Course Material:
${contextText.slice(0, 10000)}
`;

    let parsedTopics: any[] = [];
    try {
      const rawJson = await generateStructuredTextWithTimeout(
        prompt,
        "You extract academic topic trees. Return strictly JSON matching the schema.",
        20000
      );
      const parsed = TopicTreeSchema.parse(JSON.parse(rawJson));
      parsedTopics = parsed.topics;
    } catch (e) {
      console.warn("Topic generation fallback to structured defaults:", e);
      parsedTopics = [
        { name: "Core Fundamentals", subtopics: ["Foundational Concepts", "Key Principles"] },
        { name: "Applied Methods", subtopics: ["Implementation Mechanics", "Analytical Techniques"] },
        { name: "Advanced Analysis", subtopics: ["Performance Invariants", "Edge-Case Boundaries"] },
      ];
    }

    if (!isSupabaseConfigured()) {
      demoStore.topics = [];
      let topCount = 0;
      for (const t of parsedTopics) {
        topCount++;
        const parentId = `top-${topCount}`;
        demoStore.topics.push({
          id: parentId,
          user_id: user.id,
          name: t.name,
          parent_id: null,
        });

        if (t.subtopics) {
          t.subtopics.forEach((subName: string, subIdx: number) => {
            demoStore.topics.push({
              id: `${parentId}-${subIdx + 1}`,
              user_id: user.id,
              name: subName,
              parent_id: parentId,
            });
          });
        }
      }

      // Map demo chunks to topics
      demoStore.chunks.forEach((c, idx) => {
        c.topic_id = demoStore.topics[idx % demoStore.topics.length].id;
      });

      return NextResponse.json({
        success: true,
        count: demoStore.topics.length,
      });
    }

    // 2. Replace existing topics (requirement 6: replace instead of duplicating)
    await supabase.from("topics").delete().eq("user_id", user.id);

    // 3. Insert new parent and child topics
    const insertedTopics: { id: string; name: string }[] = [];

    for (const t of parsedTopics) {
      const { data: parent, error: pErr } = await supabase
        .from("topics")
        .insert({
          user_id: user.id,
          name: t.name,
          parent_id: null,
        })
        .select()
        .single();

      if (pErr) throw pErr;
      if (parent) {
        insertedTopics.push({ id: parent.id, name: parent.name });

        if (t.subtopics && t.subtopics.length > 0) {
          const childInserts = t.subtopics.map((subName: string) => ({
            user_id: user.id,
            name: subName,
            parent_id: parent.id,
          }));

          const { data: children, error: cErr } = await supabase
            .from("topics")
            .insert(childInserts)
            .select();

          if (cErr) throw cErr;
          if (children) {
            children.forEach((c) => insertedTopics.push({ id: c.id, name: c.name }));
          }
        }
      }
    }

    // 4. Requirement 6: Embed each topic ONCE (in batch), not once per chunk!
    try {
      const topicNames = insertedTopics.map((t) => t.name);
      const topicEmbeddings = await generateBatchEmbeddings(topicNames, 5);

      // Map each topic embedding to match nearest chunks
      for (let i = 0; i < insertedTopics.length; i++) {
        const topic = insertedTopics[i];
        const embedding = topicEmbeddings[i];

        const { data: matches } = await supabase.rpc("match_chunks", {
          query_embedding: embedding,
          match_count: 4,
          filter_user_id: user.id,
        });

        if (matches && matches.length > 0) {
          const chunkIdsToUpdate = matches.map((m: any) => m.id);
          await supabase
            .from("chunks")
            .update({ topic_id: topic.id })
            .in("id", chunkIdsToUpdate)
            .is("topic_id", null);
        }
      }
    } catch (embErr) {
      console.warn("Embedding mapping note:", embErr);
    }

    return NextResponse.json({
      success: true,
      count: insertedTopics.length,
    });
  } catch (error: any) {
    console.error("Topic generation error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to generate topic tree" },
      { status: 500 }
    );
  }
}

