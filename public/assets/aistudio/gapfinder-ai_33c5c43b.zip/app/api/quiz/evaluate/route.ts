import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import { generateStructuredTextWithTimeout } from "@/lib/ai/gemini";
import { GapReportSchema, RevisionPlanSchema } from "@/lib/ai/schemas";
import { demoStore } from "@/lib/db/demo-store";

export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { questionId, userAnswer, attemptId } = await req.json();

    if (!questionId || userAnswer === undefined || !attemptId) {
      return NextResponse.json(
        { error: "questionId, userAnswer, and attemptId are required" },
        { status: 400 }
      );
    }

    let question: any = null;
    let chunk: any = null;

    if (!isSupabaseConfigured()) {
      question = demoStore.questions.find((q) => q.id === questionId);
      if (question) {
        chunk = demoStore.chunks.find((c) => c.id === question.source_chunk_id) || demoStore.chunks[0];
      }
    } else {
      const { data: dbQ, error: qErr } = await supabase
        .from("quiz_questions")
        .select("*, chunks(id, content, section_label, page)")
        .eq("id", questionId)
        .single();

      if (qErr || !dbQ) {
        question = demoStore.questions.find((q) => q.id === questionId);
        chunk = demoStore.chunks.find((c) => c.id === question?.source_chunk_id) || demoStore.chunks[0];
      } else {
        question = dbQ;
        chunk = dbQ.chunks;
      }
    }

    if (!question) {
      return NextResponse.json({ error: "Question not found" }, { status: 404 });
    }

    const isCorrect =
      question.correct_answer.trim().toLowerCase() === String(userAnswer).trim().toLowerCase();

    // Update question state
    question.user_answer = userAnswer;
    question.is_correct = isCorrect;

    if (isSupabaseConfigured()) {
      await supabase
        .from("quiz_questions")
        .update({
          user_answer: userAnswer,
          is_correct: isCorrect,
        })
        .eq("id", questionId);
    }

    // Check completion of attempt
    let allQuestions: any[] = [];
    if (!isSupabaseConfigured()) {
      allQuestions = demoStore.questions.filter((q) => q.attempt_id === attemptId);
    } else {
      const { data } = await supabase
        .from("quiz_questions")
        .select("id, is_correct, topic_id, user_answer, question, correct_answer")
        .eq("attempt_id", attemptId);
      allQuestions = data || [];
    }

    if (allQuestions.length === 0) {
      allQuestions = [question];
    }

    const answered = allQuestions.filter((q) => q.is_correct !== null && q.is_correct !== undefined);
    const correctCount = answered.filter((q) => q.is_correct).length;
    const scorePercentage = answered.length > 0 ? Math.round((correctCount / answered.length) * 100) : 0;

    if (!isSupabaseConfigured()) {
      const att = demoStore.attempts.find((a) => a.id === attemptId);
      if (att) att.score = scorePercentage;
    } else {
      await supabase
        .from("quiz_attempts")
        .update({ score: scorePercentage })
        .eq("id", attemptId);
    }

    const isCompleted = answered.length === allQuestions.length;

    if (isCompleted) {
      // Group answers by topic
      const topicGroup: Record<string, { total: number; correct: number; mistakes: string[] }> = {};
      for (const q of allQuestions) {
        if (!topicGroup[q.topic_id]) {
          topicGroup[q.topic_id] = { total: 0, correct: 0, mistakes: [] };
        }
        topicGroup[q.topic_id].total++;
        if (q.is_correct) {
          topicGroup[q.topic_id].correct++;
        } else {
          topicGroup[q.topic_id].mistakes.push(
            `Question: "${q.question}" | Chosen: "${q.user_answer}" | Expected: "${q.correct_answer}"`
          );
        }
      }

      // Topic name map
      const topicNameMap: Record<string, string> = {};
      if (!isSupabaseConfigured()) {
        demoStore.topics.forEach((t) => {
          topicNameMap[t.id] = t.name;
        });
      } else {
        const { data: dbTopics } = await supabase
          .from("topics")
          .select("id, name")
          .in("id", Object.keys(topicGroup));
        (dbTopics || []).forEach((t) => {
          topicNameMap[t.id] = t.name;
        });
      }

      const computedGaps = Object.entries(topicGroup).map(([topicId, stats]) => {
        const score = Math.round((stats.correct / stats.total) * 100);
        let category: "weak" | "medium" | "strong" = "medium";
        if (score < 40) category = "weak";
        else if (score >= 75) category = "strong";

        let reason = "";
        if (category === "weak") {
          reason = `Fundamental conceptual gap identified in ${topicNameMap[topicId] || "this topic"} based on quiz responses.`;
        } else if (category === "medium") {
          reason = `Demonstrates good understanding of ${topicNameMap[topicId] || "this topic"}, but missed boundary edge-cases.`;
        } else {
          reason = `Demonstrated strong mastery and precision in ${topicNameMap[topicId] || "this topic"}.`;
        }

        return {
          topic_id: topicId,
          topic_name: topicNameMap[topicId] || "Core Topic",
          score,
          category,
          reason,
        };
      });

      // Try AI reason generation if available
      if (process.env.GEMINI_API_KEY) {
        try {
          const reasonPrompt = `
Generate a concise one-line academic diagnosis for each tested topic based on student performance:
${JSON.stringify(computedGaps, null, 2)}
Return strictly JSON matching:
{
  "topicGaps": [
    { "topic_id": "id", "topic_name": "name", "score": 0, "category": "weak", "reason": "One concise line" }
  ]
}
`;
          const rawReason = await generateStructuredTextWithTimeout(reasonPrompt, undefined, 15000);
          const parsed = GapReportSchema.parse(JSON.parse(rawReason));
          parsed.topicGaps.forEach((pg) => {
            const match = computedGaps.find((cg) => cg.topic_id === pg.topic_id);
            if (match && pg.reason) match.reason = pg.reason;
          });
        } catch {
          // Use default reasons
        }
      }

      if (!isSupabaseConfigured()) {
        computedGaps.forEach((g) => {
          demoStore.topicScores.push({
            id: `ts-${Date.now()}-${g.topic_id}`,
            user_id: user.id,
            topic_id: g.topic_id,
            attempt_id: attemptId,
            score: g.score,
            reason: g.reason,
          });
        });
      } else {
        await supabase.from("topic_scores").insert(
          computedGaps.map((g) => ({
            user_id: user.id,
            topic_id: g.topic_id,
            attempt_id: attemptId,
            score: g.score,
            reason: g.reason,
          }))
        );
      }
    }

    return NextResponse.json({
      isCorrect,
      correctAnswer: question.correct_answer,
      explanation: question.explanation,
      citationQuote: question.citation_quote || (chunk ? chunk.content.slice(0, 160) : ""),
      sourceCitation: chunk
        ? `Section: ${chunk.section_label || "Notes"} (Page ${chunk.page || 1})`
        : "Verified Course Material",
      isCompleted,
    });
  } catch (error: any) {
    console.error("Quiz evaluate error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
