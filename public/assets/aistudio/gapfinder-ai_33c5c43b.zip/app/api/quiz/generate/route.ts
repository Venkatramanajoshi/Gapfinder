import { NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import {
  generateStructuredTextWithTimeout,
} from "@/lib/ai/gemini";
import { QuizQuestionsSchema } from "@/lib/ai/schemas";
import { demoStore } from "@/lib/db/demo-store";

export const maxDuration = 60;

export async function POST() {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    let allTopics: any[] = [];
    if (!isSupabaseConfigured()) {
      allTopics = demoStore.topics;
    } else {
      const { data: dbTopics, error: topicErr } = await supabase
        .from("topics")
        .select("id, name, parent_id")
        .eq("user_id", user.id);

      if (topicErr || !dbTopics || dbTopics.length === 0) {
        allTopics = demoStore.topics;
      } else {
        allTopics = dbTopics;
      }
    }

    if (!allTopics || allTopics.length === 0) {
      allTopics = demoStore.topics;
    }

    // Identify leaf topics
    const parentIds = new Set(allTopics.filter((t) => t.parent_id).map((t) => t.parent_id));
    const leafTopics = allTopics.filter((t) => t.parent_id !== null || !parentIds.has(t.id));
    const selectedTopics = leafTopics.slice(0, 5);
    const attemptId = `att-${Date.now()}`;

    if (!isSupabaseConfigured()) {
      demoStore.attempts.push({
        id: attemptId,
        user_id: user.id,
        score: 0,
        created_at: new Date().toISOString(),
      });
    } else {
      await supabase
        .from("quiz_attempts")
        .insert({
          id: attemptId,
          user_id: user.id,
          score: 0,
        })
        .select();
    }

    // Retrieve chunk for each topic
    const topicChunkPairs: { topic: any; chunk: any }[] = [];
    for (const topic of selectedTopics) {
      let matchedChunks = demoStore.chunks.filter((c) => c.topic_id === topic.id);
      if (matchedChunks.length === 0) matchedChunks = demoStore.chunks;
      const topChunk = matchedChunks[0] || demoStore.chunks[0];
      topicChunkPairs.push({ topic, chunk: topChunk });
    }

    // Generate in a single Gemini call for ultra-fast response
    let aiQuestions: any[] = [];
    if (process.env.GEMINI_API_KEY) {
      const contextBlocks = topicChunkPairs
        .map(
          (tcp, i) =>
            `Topic ${i + 1}: "${tcp.topic.name}" [Chunk ID: ${tcp.chunk.id}, Section: ${tcp.chunk.section_label || "Notes"}]\nExcerpt: ${tcp.chunk.content}`
        )
        .join("\n\n---\n\n");

      const prompt = `
You are an academic assessment engine.
Generate exactly 1 multiple-choice question for EACH of the following ${topicChunkPairs.length} topics using ONLY its corresponding excerpt.
STRICT INSTRUCTION: Use only the provided excerpt for each question. Do not extrapolate or use outside knowledge.

Required JSON format:
{
  "questions": [
    {
      "question": "Question text here?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct_answer": "Exact matching string of correct option",
      "source_chunk_id": "chunk-id-from-excerpt",
      "citation_quote": "Exact short substring from excerpt verifying answer",
      "explanation": "Clear reason why this is correct based strictly on the excerpt"
    }
  ]
}

Topics and Excerpts:
${contextBlocks}
`;

      try {
        const rawJson = await generateStructuredTextWithTimeout(prompt, undefined, 12000);
        const parsed = QuizQuestionsSchema.parse(JSON.parse(rawJson));
        aiQuestions = parsed.questions || [];
      } catch (err) {
        // Fallback gracefully to grounded extraction
      }
    }

    // Assemble final questions
    const finalQuestions: any[] = [];
    topicChunkPairs.forEach((tcp, index) => {
      const topic = tcp.topic;
      const topChunk = tcp.chunk;
      const aiQ = aiQuestions[index];

      let qData: any = null;
      if (aiQ && aiQ.question && aiQ.options && aiQ.options.length === 4 && aiQ.correct_answer) {
        qData = {
          question: aiQ.question,
          options: aiQ.options,
          correct_answer: aiQ.correct_answer,
          source_chunk_id: topChunk.id,
          citation_quote: aiQ.citation_quote || topChunk.content.slice(0, 100),
          explanation: aiQ.explanation || `Directly supported by ${topChunk.section_label || "notes"}.`,
        };
      } else {
        const sentences = topChunk.content.split(". ").filter((s: string) => s.trim().length > 20);
        const firstSentence = (sentences[0] || topChunk.content.slice(0, 100)).trim() + ".";
        qData = {
          question: `According to your course material on "${topic.name}", which of the following is explicitly verified?`,
          options: [
            firstSentence,
            `The concept is strictly deprecated in modern system architectures.`,
            `The operation executes in unbounded exponential runtime under all conditions.`,
            `No formal definition or invariant exists within the provided notes.`,
          ],
          correct_answer: firstSentence,
          source_chunk_id: topChunk.id,
          citation_quote: firstSentence,
          explanation: `Directly stated in ${topChunk.section_label || "course notes"}: "${firstSentence}"`,
        };
      }

      finalQuestions.push({
        id: `q-${Date.now()}-${index + 1}`,
        attempt_id: attemptId,
        topic_id: topic.id,
        topic_name: topic.name,
        question: qData.question,
        options: qData.options,
        correct_answer: qData.correct_answer,
        source_chunk_id: topChunk.id,
        citation_quote: qData.citation_quote,
        explanation: qData.explanation,
      });
    });

    if (!isSupabaseConfigured()) {
      demoStore.questions.push(...finalQuestions);
    } else {
      await supabase.from("quiz_questions").insert(
        finalQuestions.map((r) => ({
          id: r.id,
          attempt_id: r.attempt_id,
          topic_id: r.topic_id,
          question: r.question,
          options: r.options,
          correct_answer: r.correct_answer,
          source_chunk_id: r.source_chunk_id,
          explanation: r.explanation,
          citation_quote: r.citation_quote,
        }))
      );
    }

    // REQUIREMENT: DO NOT send correct_answer to client before user answers!
    const clientQuestions = finalQuestions.map((q) => ({
      id: q.id,
      attempt_id: q.attempt_id,
      topic_id: q.topic_id,
      topic_name: q.topic_name,
      question: q.question,
      options: q.options,
      source_chunk_id: q.source_chunk_id,
    }));

    return NextResponse.json({
      attemptId,
      questions: clientQuestions,
    });
  } catch (error: any) {
    console.error("Quiz generate error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to generate diagnostic quiz" },
      { status: 500 }
    );
  }
}
