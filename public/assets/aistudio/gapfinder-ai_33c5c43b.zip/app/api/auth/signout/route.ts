import { NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/db/supabase-server";

export async function POST() {
  try {
    const supabase = createServerSupabase();
    await supabase.auth.signOut();
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
