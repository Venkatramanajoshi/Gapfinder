import { NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import { demoStore } from "@/lib/db/demo-store";

export async function GET() {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!isSupabaseConfigured()) {
      const enriched = demoStore.documents.map((doc) => {
        const chunkCount = demoStore.chunks.filter((c) => c.document_id === doc.id).length;
        return {
          ...doc,
          chunkCount,
        };
      });
      return NextResponse.json({ documents: enriched });
    }

    const { data: documents, error: docError } = await supabase
      .from("documents")
      .select("id, name, type, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (docError) {
      const enriched = demoStore.documents.map((doc) => ({
        ...doc,
        chunkCount: demoStore.chunks.filter((c) => c.document_id === doc.id).length,
      }));
      return NextResponse.json({ documents: enriched });
    }

    // Get chunk counts per document
    const { data: chunks } = await supabase
      .from("chunks")
      .select("document_id")
      .eq("user_id", user.id);

    const chunkCounts: Record<string, number> = {};
    (chunks || []).forEach((c: { document_id: string }) => {
      chunkCounts[c.document_id] = (chunkCounts[c.document_id] || 0) + 1;
    });

    const enriched = (documents || []).map((doc: any) => ({
      ...doc,
      chunkCount: chunkCounts[doc.id] || 0,
    }));

    return NextResponse.json({ documents: enriched });
  } catch (error: any) {
    const enriched = demoStore.documents.map((doc) => ({
      ...doc,
      chunkCount: demoStore.chunks.filter((c) => c.document_id === doc.id).length,
    }));
    return NextResponse.json({ documents: enriched });
  }
}

