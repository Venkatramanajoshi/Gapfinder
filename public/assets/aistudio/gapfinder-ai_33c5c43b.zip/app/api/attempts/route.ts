import { NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import { demoStore } from "@/lib/db/demo-store";

export async function GET() {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!isSupabaseConfigured()) {
      return NextResponse.json({ attempts: demoStore.attempts });
    }

    const { data: attempts, error } = await supabase
      .from("quiz_attempts")
      .select("id, score, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true });

    if (error) {
      return NextResponse.json({ attempts: demoStore.attempts });
    }

    return NextResponse.json({ attempts: attempts || [] });
  } catch (error: any) {
    return NextResponse.json({ attempts: demoStore.attempts });
  }
}

