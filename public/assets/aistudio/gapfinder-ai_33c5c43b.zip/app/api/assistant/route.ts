import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, getAuthenticatedUser, isSupabaseConfigured } from "@/lib/db/supabase-server";
import {
  generateEmbedding,
  generateStructuredTextWithTimeout,
} from "@/lib/ai/gemini";
import { demoStore } from "@/lib/db/demo-store";

export const maxDuration = 30;

export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabase();
    const user = await getAuthenticatedUser(supabase);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { query } = await req.json();

    if (!query || !query.trim()) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 });
    }

    let chunks: any[] = [];

    if (!isSupabaseConfigured()) {
      // Find matching chunks in demoStore based on keyword overlap
      const queryWords = query.toLowerCase().split(/\s+/).filter((w: string) => w.length > 3);
      const scored = demoStore.chunks.map((c) => {
        let matchScore = 0;
        const contentLower = c.content.toLowerCase();
        queryWords.forEach((w: string) => {
          if (contentLower.includes(w)) matchScore += 1;
        });
        return { chunk: c, score: matchScore };
      });

      scored.sort((a, b) => b.score - a.score);
      const relevant = scored.filter((s) => s.score > 0);

      if (relevant.length === 0) {
        return NextResponse.json({
          answer: "Not found in your material.",
          citations: [],
        });
      }

      chunks = relevant.slice(0, 3).map((r) => r.chunk);
    } else {
      try {
        const queryEmbedding = await generateEmbedding(query);
        const { data: matched, error: matchErr } = await supabase.rpc("match_chunks", {
          query_embedding: queryEmbedding,
          match_count: 4,
          filter_user_id: user.id,
        });

        if (matchErr || !matched || matched.length === 0) {
          return NextResponse.json({
            answer: "Not found in your material.",
            citations: [],
          });
        }

        const topSimilarity = matched[0]?.similarity ?? 0;
        if (topSimilarity < 0.20) {
          return NextResponse.json({
            answer: "Not found in your material. This question does not match any concepts covered in your uploaded syllabus or notes.",
            citations: [],
          });
        }
        chunks = matched;
      } catch {
        chunks = demoStore.chunks.slice(0, 2);
      }
    }

    const context = chunks
      .map((c: any) => `[Source: ${c.section_label || "Notes"}] ${c.content}`)
      .join("\n\n---\n\n");

    const prompt = `
Answer the student's question based SOLELY on the provided context chunks.
If the context does not contain enough information to answer completely, respond: "Not found in your material."
Do not extrapolate or use outside knowledge. Cite the section names inline when stating facts.

Context:
${context}

Student Question:
${query}
`;

    let answer = "Not found in your material.";
    if (process.env.GEMINI_API_KEY) {
      try {
        const responseText = await generateStructuredTextWithTimeout(
          prompt,
          "You are an academic mentor answering solely from provided notes. If the text does not directly answer the question, reply strictly: Not found in your material.",
          20000
        );
        answer = responseText.replace(/```[a-z]*\n?|\n?```/g, "").trim();
      } catch (err) {
        answer = `Based on ${chunks[0]?.section_label || "your notes"}: ${chunks[0]?.content.slice(0, 220)}...`;
      }
    } else {
      answer = `Based on ${chunks[0]?.section_label || "your notes"}: ${chunks[0]?.content.slice(0, 220)}...`;
    }

    const citations = chunks.map((c: any) => ({
      section: c.section_label || "Uploaded Notes",
      page: c.page || 1,
      snippet: c.content.slice(0, 160) + "...",
    }));

    return NextResponse.json({
      answer: answer || "Not found in your material.",
      citations,
    });
  } catch (error: any) {
    console.error("Assistant API error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to process question" },
      { status: 500 }
    );
  }
}
