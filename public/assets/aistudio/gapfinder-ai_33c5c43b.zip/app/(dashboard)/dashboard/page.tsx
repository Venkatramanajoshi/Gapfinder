"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/components/providers/AuthProvider";
import {
  Award,
  BookOpen,
  Calendar,
  ArrowRight,
  TrendingUp,
  Sparkles,
  AlertCircle,
  HelpCircle,
  UploadCloud,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  Cell,
} from "recharts";

export default function DashboardPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [attempts, setAttempts] = useState<any[]>([]);
  const [topicGaps, setTopicGaps] = useState<any[]>([]);
  const [totalTopics, setTotalTopics] = useState(0);

  useEffect(() => {
    async function loadDashboard() {
      setLoading(true);
      try {
        const [attRes, planRes, topRes] = await Promise.all([
          fetch("/api/attempts"),
          fetch("/api/plan/latest"),
          fetch("/api/topics"),
        ]);

        const attData = await attRes.json();
        const planData = await planRes.json();
        const topData = await topRes.json();

        if (attData.attempts) setAttempts(attData.attempts);
        if (planData.gaps) setTopicGaps(planData.gaps);
        if (topData.rawCount) setTotalTopics(topData.rawCount);
      } catch (err) {
        console.error("Dashboard data load error:", err);
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, [user]);

  // Compute metrics
  const latestAttempt = attempts.length > 0 ? attempts[attempts.length - 1] : null;
  const latestScore = latestAttempt ? Math.round(latestAttempt.score) : 72;
  const weakCount = topicGaps.filter((g) => g.category === "weak").length;
  const mediumCount = topicGaps.filter((g) => g.category === "medium").length;
  const strongCount = topicGaps.filter((g) => g.category === "strong").length;

  // Chart data format
  const chartAttempts =
    attempts.length > 0
      ? attempts.map((a, i) => ({
          name: `Quiz ${i + 1}`,
          score: Math.round(a.score),
          date: new Date(a.created_at).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
        }))
      : [
          { name: "Quiz 1", score: 38 },
          { name: "Quiz 2", score: 55 },
          { name: "Quiz 3", score: 72 },
        ];

  const strengthBarData = (topicGaps.length > 0 ? topicGaps : [
    { topic_name: "Tree Structures", score: 85, category: "strong" },
    { topic_name: "Hash Tables", score: 75, category: "strong" },
    { topic_name: "AVL Balancing", score: 50, category: "medium" },
    { topic_name: "Graph Traversals (BFS/DFS)", score: 25, category: "weak" },
    { topic_name: "Dynamic Programming Memoization", score: 20, category: "weak" },
  ]).slice(0, 5).map((t) => ({
    name: t.topic_name.length > 18 ? t.topic_name.slice(0, 16) + "…" : t.topic_name,
    score: t.score,
    category: t.category,
  }));

  const getBarColor = (category: string) => {
    if (category === "weak") return "#ef4444";
    if (category === "medium") return "#f59e0b";
    return "#10b981";
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100 mb-2">
            <Sparkles className="w-3 h-3" /> Diagnostic Engine Active
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Student Knowledge Overview</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Subject: <span className="font-semibold text-slate-800">CS201 Data Structures & Algorithms</span> &bull; 3 documents indexed
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="/upload"
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition flex items-center gap-1.5"
          >
            <UploadCloud className="w-3.5 h-3.5" />
            Upload New
          </Link>
          <button
            onClick={() => router.push("/quiz")}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition flex items-center gap-1.5"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            Take Diagnostic Quiz
          </button>
        </div>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Latest Score */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Latest Diagnostic Score</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-slate-900">{latestScore}%</div>
            <div className="flex items-center gap-1 text-[11px] text-green-600 font-semibold mt-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+34% across 3 diagnostic attempts</span>
            </div>
          </div>
        </div>

        {/* Card 2: Topics Covered */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Topics Analyzed</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-slate-900">{totalTopics || 10}</div>
            <div className="text-[11px] text-slate-500 mt-1">
              Extracted from syllabus & lecture notes
            </div>
          </div>
        </div>

        {/* Card 3: Active Gaps */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Active Knowledge Gaps</span>
            <div className="w-7 h-7 rounded-lg bg-red-50 text-red-600 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-red-600">{weakCount || 2} Topics</div>
            <div className="text-[11px] text-red-600/90 font-medium mt-1">
              Scoring below 40% threshold
            </div>
          </div>
        </div>

        {/* Card 4: Exam Target */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Days to Final Exam</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-slate-900">5 Days</div>
            <div className="text-[11px] text-amber-700 font-medium mt-1">
              3.0 hrs/day allocated on plan
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Action Callout Card */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 text-[11px] font-semibold">
              <Sparkles className="w-3 h-3 text-indigo-300" />
              Highest Priority Action
            </div>
            <h3 className="text-lg font-bold">
              Follow Day 1 Plan: Review Graph Traversals (BFS vs DFS)
            </h3>
            <p className="text-xs text-indigo-200 leading-relaxed">
              Diagnostic quiz revealed confusion between BFS queue mechanics and DFS stack recursion (Score: 25%). 100 minutes of targeted problem tracing is scheduled for today.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href="/plan"
              className="px-4 py-2.5 rounded-xl bg-white text-indigo-950 hover:bg-indigo-50 font-semibold text-xs transition shadow-xs flex items-center gap-1.5 shrink-0"
            >
              <span>Open Day 1 Schedule</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>

      {/* Two Column Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Progress Across Attempts */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Diagnostic Mastery Across Attempts</h3>
              <p className="text-[11px] text-slate-500">Track knowledge growth from initial diagnostic to mastery</p>
            </div>
            <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
              Recharts
            </span>
          </div>
          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartAttempts} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis domain={[0, 100]} stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e293b", borderRadius: "10px", color: "#fff", fontSize: "12px", border: "none" }}
                  formatter={(val: any) => [`${val}%`, "Score"]}
                />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#4f46e5"
                  strokeWidth={3}
                  dot={{ r: 5, fill: "#4f46e5", stroke: "#ffffff", strokeWidth: 2 }}
                  activeDot={{ r: 7 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Topic Strength Distribution */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Current Topic Strength Breakdown</h3>
              <p className="text-[11px] text-slate-500">Red = Weak (&lt;40%), Amber = Medium (40-74%), Green = Strong (&ge;75%)</p>
            </div>
            <div className="flex gap-1 text-[10px] font-bold">
              <span className="text-red-600 bg-red-50 px-1.5 py-0.5 rounded">{weakCount || 2} W</span>
              <span className="text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">{mediumCount || 1} M</span>
              <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded">{strongCount || 2} S</span>
            </div>
          </div>
          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={strengthBarData} layout="vertical" margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" domain={[0, 100]} stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={11} tickLine={false} width={130} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e293b", borderRadius: "10px", color: "#fff", fontSize: "12px", border: "none" }}
                  formatter={(val: any) => [`${val}%`, "Mastery"]}
                />
                <Bar dataKey="score" radius={[0, 6, 6, 0]}>
                  {strengthBarData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getBarColor(entry.category)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Link
          href="/topics"
          className="bg-white hover:bg-slate-50 border border-slate-200/80 rounded-2xl p-4 transition-all group flex items-center justify-between"
        >
          <div>
            <div className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
              Explore Topic Map
            </div>
            <div className="text-[11px] text-slate-500">Interactive collapsible hierarchy</div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
        </Link>

        <Link
          href="/report"
          className="bg-white hover:bg-slate-50 border border-slate-200/80 rounded-2xl p-4 transition-all group flex items-center justify-between"
        >
          <div>
            <div className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
              View Detailed Gap Report
            </div>
            <div className="text-[11px] text-slate-500">Specific diagnostic reasoning</div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
        </Link>

        <Link
          href="/assistant"
          className="bg-white hover:bg-slate-50 border border-slate-200/80 rounded-2xl p-4 transition-all group flex items-center justify-between"
        >
          <div>
            <div className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
              Explain-This-Topic Assistant
            </div>
            <div className="text-[11px] text-slate-500">Grounded with section citations</div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
        </Link>
      </div>
    </div>
  );
}
