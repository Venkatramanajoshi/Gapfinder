# GapFinder AI — 7-Hour Hackathon Diagnostic Study App

**Find what you don't know.**

GapFinder AI is a full-stack diagnostic study application designed for intensive exam preparation. Rather than providing generic chat interactions, it ingests a student's real course materials (syllabi, lecture notes, and past exam papers), maps out a structured topic tree, generates multiple-choice quizzes grounded exclusively in their notes with exact citations, diagnoses knowledge gaps, and produces an automated, prioritized day-by-day revision schedule.

---

## 1. Core Architecture & RAG Pipeline

```
[Student Course Upload: Syllabus / Notes / Past Paper]
                      │
                      ▼
[Heuristic Chunker: ~350 words, 40-word overlap, section & page extraction]
                      │
                      ▼
[Google Gemini Embeddings: gemini-embedding-2-preview (768-dim)]
                      │
                      ▼
[Postgres pgvector Vector Store with Row Level Security (RLS)]
                      │
                      ├─────────────────────────────────────────┐
                      ▼                                         ▼
         [Topic Tree Extraction]                       [Diagnostic Quiz]
     (Gemini 3.8 + TopicTreeSchema)             (Strict Top-k Vector Retrieval)
                      │                                         │
                      ▼                                         ▼
            [Topic Map Hierarchy]                      [MCQs with Source Citations]
                      │                                         │
                      └────────────────────┬────────────────────┘
                                           ▼
                                 [Answer Evaluation]
                                           │
                                           ▼
                                   [Gap Analysis Report]
                           (Weak <40%, Medium 40-74%, Strong >=75%)
                                           │
                                           ▼
                              [Prioritized Revision Plan]
                          (60% time allocated to Weak Topics)
```

### RAG Pipeline Mechanics
1. **Ingest & Chunking**: Text is extracted from uploaded documents and chunked into ~350-word passages with a 40-word overlap. Structural headings (`# Section`, `Unit`, `Lecture`) and page numbers are preserved in `section_label` and `page` columns.
2. **Embeddings & Vector Store**: Each chunk is embedded into a 768-dimensional vector using Google Gemini's modern embedding model. In Supabase, the vector is stored in a `vector(768)` column with cosine distance indexing (`<=>`).
3. **Topic Mapping**: Syllabi text is parsed by Gemini to establish an academic hierarchy. Unassigned chunks are automatically linked to their nearest topic via vector similarity.
4. **Retrieval**: Diagnostic quiz generation retrieves the top-3 closest chunks per topic for the authenticated user (`match_chunks`).
5. **Strict Grounding & Citations**: The LLM is strictly instructed to generate questions derived *only* from the retrieved chunk content. Each question records the `source_chunk_id` and the exact snippet in `citation_quote`.
6. **Explain-This-Topic Assistant**: Performs vector retrieval first. If cosine similarity is below relevance thresholds, it immediately responds: *"Not found in your material."* Otherwise, answers strictly cite section headings and page numbers.

---

## 2. Quickstart & Hackathon Judge Walkthrough

### Instant 1-Click Demo
The app includes a preloaded demo dataset for **CS201 Data Structures & Algorithms**:
- **Email**: `demo@gapfinder.app`
- **Password**: `Demo@1234`
- Click **"Try Demo"** on the landing page or login page to enter immediately with pre-indexed syllabus documents, past quiz attempts, and diagnostic gap reports.

### Local Development Setup
```bash
# 1. Install dependencies
npm install

# 2. Run the full-stack dev server (port 3000)
npm run dev
```

---

## 3. Environment Variables (`.env.example`)

```env
# Gemini API Key for generation and vector embeddings
GEMINI_API_KEY="AIzaSy..."

# Supabase PostgreSQL & pgvector Credentials (for Vercel deployment)
NEXT_PUBLIC_SUPABASE_URL="https://xyz.supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="eyJhbGciOi..."
SUPABASE_SERVICE_ROLE_KEY="eyJhbGciOi..."

# Application URL
APP_URL="http://localhost:3000"
```

---

## 4. Supabase Database Migration (`schema.sql`)

Run this SQL script in the **Supabase SQL Editor** to initialize PostgreSQL with `pgvector` and Row Level Security:

```sql
create extension if not exists vector;

create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  created_at timestamptz default now()
);

create table if not exists public.documents (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  name text not null,
  type text check (type in ('syllabus', 'notes', 'past_paper')) not null,
  created_at timestamptz default now()
);

create table if not exists public.topics (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  name text not null,
  parent_id uuid references public.topics(id) on delete cascade,
  created_at timestamptz default now()
);

create table if not exists public.chunks (
  id uuid default gen_random_uuid() primary key,
  document_id uuid references public.documents(id) on delete cascade not null,
  user_id uuid references auth.users on delete cascade not null,
  content text not null,
  section_label text,
  page int default 1,
  topic_id uuid references public.topics(id) on delete set null,
  embedding vector(768),
  created_at timestamptz default now()
);

create table if not exists public.quiz_attempts (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  score numeric(5,2) not null default 0.00,
  created_at timestamptz default now()
);

create table if not exists public.quiz_questions (
  id uuid default gen_random_uuid() primary key,
  attempt_id uuid references public.quiz_attempts(id) on delete cascade not null,
  topic_id uuid references public.topics(id) on delete cascade not null,
  question text not null,
  options jsonb not null,
  correct_answer text not null,
  source_chunk_id uuid references public.chunks(id) on delete set null,
  user_answer text,
  is_correct boolean,
  explanation text,
  citation_quote text,
  created_at timestamptz default now()
);

create table if not exists public.topic_scores (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  topic_id uuid references public.topics(id) on delete cascade not null,
  attempt_id uuid references public.quiz_attempts(id) on delete cascade not null,
  score numeric(5,2) not null,
  reason text,
  created_at timestamptz default now()
);

create table if not exists public.revision_plans (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  days_available int not null,
  hours_per_day numeric(4,2) not null,
  plan_json jsonb not null,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.documents enable row level security;
alter table public.topics enable row level security;
alter table public.chunks enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.topic_scores enable row level security;
alter table public.revision_plans enable row level security;

create policy "Users own profiles" on public.profiles for all using (auth.uid() = id);
create policy "Users own documents" on public.documents for all using (auth.uid() = user_id);
create policy "Users own topics" on public.topics for all using (auth.uid() = user_id);
create policy "Users own chunks" on public.chunks for all using (auth.uid() = user_id);
create policy "Users own quiz_attempts" on public.quiz_attempts for all using (auth.uid() = user_id);
create policy "Users own quiz_questions" on public.quiz_questions for all using (
  exists (select 1 from public.quiz_attempts where quiz_attempts.id = quiz_questions.attempt_id and quiz_attempts.user_id = auth.uid())
);
create policy "Users own topic_scores" on public.topic_scores for all using (auth.uid() = user_id);
create policy "Users own revision_plans" on public.revision_plans for all using (auth.uid() = user_id);

create or replace function match_chunks (
  query_embedding vector(768),
  match_count int,
  filter_user_id uuid
)
returns table (
  id uuid,
  document_id uuid,
  content text,
  section_label text,
  topic_id uuid,
  similarity float
)
language plpgsql
as $$
begin
  return query
  select
    chunks.id,
    chunks.document_id,
    chunks.content,
    chunks.section_label,
    chunks.topic_id,
    1 - (chunks.embedding <=> query_embedding) as similarity
  from chunks
  where chunks.user_id = filter_user_id
  order by chunks.embedding <=> query_embedding
  limit match_count;
end;
$$;
```

---

## 5. Revision Plan Prioritization Rules
- **Weak Topics (<40% Mastery)**: Receive 60% of total available revision hours. Focus on core invariant definitions, manual tracing, and foundational drills.
- **Medium Topics (40–74% Mastery)**: Receive 30% of study time. Targeted boundary condition drills and edge-case review.
- **Strong Topics (≥75% Mastery)**: Receive 10% for rapid recall checks and maintaining retention.

---

## 6. Limitations & Future Enhancements
- **Multi-Modal Diagrams**: In future versions, diagram images and mathematical formulas in handwritten lecture notes will be processed using Gemini's visual OCR capabilities.
- **Spaced Repetition Schedule (SM-2)**: Exporting the revision schedule to Anki flashcard decks or Google Calendar events.
- **Collaborative Study Groups**: Shared cohort topic maps allowing teachers to identify class-wide weak topics across all students.
