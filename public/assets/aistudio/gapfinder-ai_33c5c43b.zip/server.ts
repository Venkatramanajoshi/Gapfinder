import express, { Request, Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { db } from "./server/db.js";
import {
  generateEmbedding,
  generateStructuredText,
  hasGeminiKey,
} from "./server/gemini.js";
import { chunkText } from "./server/chunker.js";
import {
  TopicTreeSchema,
  QuizQuestionsSchema,
  RevisionPlanSchema,
} from "./server/schemas.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || "3000", 10);

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Helper to extract or resolve user id
function resolveUserId(req: Request): string {
  const headerId = req.headers["x-user-id"] as string;
  if (headerId && headerId.trim()) return headerId.trim();
  const bodyId = req.body?.userId;
  if (bodyId && typeof bodyId === "string") return bodyId.trim();
  const queryId = req.query?.userId as string;
  if (queryId && queryId.trim()) return queryId.trim();

  // Fallback to demo user
  const demo = db.findProfileByEmail("demo@gapfinder.app");
  return demo ? demo.id : "usr-demo";
}

// ==========================================
// AUTH & SEED API
// ==========================================

app.post("/api/auth/login", (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email is required" });
  }
  let profile = db.findProfileByEmail(email);
  if (!profile) {
    profile = db.createProfile(email);
  }
  res.json({ user: profile });
});

app.post("/api/auth/signup", (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Email is required" });
  }
  const profile = db.createProfile(email);
  res.json({ user: profile });
});

app.post("/api/auth/demo", (req: Request, res: Response) => {
  const demo = db.findProfileByEmail("demo@gapfinder.app") || db.createProfile("demo@gapfinder.app");
  res.json({ user: demo });
});

app.get("/api/auth/me", (req: Request, res: Response) => {
  const userId = resolveUserId(req);
  const profile = db.profiles.find((p) => p.id === userId);
  if (!profile) {
    const demo = db.findProfileByEmail("demo@gapfinder.app")!;
    return res.json({ user: demo });
  }
  res.json({ user: profile });
});

app.get("/api/seed", async (req: Request, res: Response) => {
  await db.seedDemoUser();
  res.json({
    message: "Demo account seeded successfully",
    credentials: { email: "demo@gapfinder.app", password: "Demo@1234Password" },
    subject: "CS201 Data Structures & Algorithms",
    stats: {
      documents: db.documents.length,
      topics: db.topics.length,
      chunks: db.chunks.length,
      attempts: db.quizAttempts.length,
    },
  });
});

// ==========================================
// DOCUMENTS & INGESTION
// ==========================================

app.get("/api/documents", (req: Request, res: Response) => {
  const userId = resolveUserId(req);
  const userDocs = db.documents.filter((d) => d.user_id === userId);
  const userChunks = db.chunks.filter((c) => c.user_id === userId);

  const enriched = userDocs.map((doc) => ({
    ...doc,
    chunkCount: userChunks.filter((c) => c.document_id === doc.id).length,
  }));
  res.json({ documents: enriched });
});

app.post("/api/ingest", async (req: Request, res: Response) => {
  try {
    const userId = resolveUserId(req);
    const { name, type, text } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: "Document text content is required" });
    }
    const docType = type === "syllabus" || type === "past_paper" ? type : "notes";
    const docName = name && name.trim() ? name.trim() : "Uploaded Material";

    const docId = "doc-" + Math.random().toString(36).substring(2, 9);
    const newDoc = {
      id: docId,
      user_id: userId,
      name: docName,
      type: docType as "syllabus" | "notes" | "past_paper",
      created_at: new Date().toISOString(),
    };
    db.documents.push(newDoc);

    // Chunking text (~350 words, 40 word overlap)
    const rawChunks = chunkText(text, 350, 40);

    for (let i = 0; i < rawChunks.length; i++) {
      const c = rawChunks[i];
      const embedding = await generateEmbedding(c.content);
      const chunkId = "chk-" + Math.random().toString(36).substring(2, 9);
      db.chunks.push({
        id: chunkId,
        document_id: docId,
        user_id: userId,
        content: c.content,
        section_label: c.sectionLabel || `${docName} - Part ${i + 1}`,
        page: c.page || 1,
        topic_id: null,
        embedding,
        created_at: new Date().toISOString(),
      });
    }

    res.json({
      success: true,
      documentId: docId,
      documentName: docName,
      chunksCreated: rawChunks.length,
    });
  } catch (error: any) {
    console.error("Ingest error:", error);
    res.status(500).json({ error: error.message || "Failed to ingest document" });
  }
});

// ==========================================
// TOPIC MAP GENERATION
// ==========================================

app.get("/api/topics", (req: Request, res: Response) => {
  const userId = resolveUserId(req);
  const userTopics = db.topics.filter((t) => t.user_id === userId);
  const userScores = db.topicScores.filter((s) => s.user_id === userId);
  const userChunks = db.chunks.filter((c) => c.user_id === userId);

  // Group topics into hierarchy
  const parents = userTopics.filter((t) => !t.parent_id);
  const hierarchy = parents.map((p) => {
    const subtopics = userTopics
      .filter((t) => t.parent_id === p.id)
      .map((sub) => {
        const latestScore = [...userScores]
          .reverse()
          .find((s) => s.topic_id === sub.id);
        const chunkCount = userChunks.filter((c) => c.topic_id === sub.id).length;
        return {
          ...sub,
          score: latestScore?.score ?? null,
          category: latestScore?.category ?? "unscored",
          reason: latestScore?.reason ?? null,
          chunkCount,
        };
      });

    const parentScore = [...userScores].reverse().find((s) => s.topic_id === p.id);
    const parentChunks = userChunks.filter(
      (c) => c.topic_id === p.id || subtopics.some((st) => st.id === c.topic_id)
    ).length;

    return {
      ...p,
      score: parentScore?.score ?? null,
      category: parentScore?.category ?? "unscored",
      chunkCount: parentChunks,
      subtopics,
    };
  });

  res.json({ topics: hierarchy, rawCount: userTopics.length });
});

app.post("/api/topics/generate", async (req: Request, res: Response) => {
  try {
    const userId = resolveUserId(req);

    // Fetch Syllabus chunks first, fallback to all chunks
    let userChunks = db.chunks.filter((c) => {
      const doc = db.documents.find((d) => d.id === c.document_id);
      return c.user_id === userId && doc?.type === "syllabus";
    });

    if (userChunks.length === 0) {
      userChunks = db.chunks.filter((c) => c.user_id === userId);
    }

    if (userChunks.length === 0) {
      return res.status(400).json({ error: "No course material uploaded yet. Please upload a syllabus or notes first." });
    }

    const contextText = userChunks
      .slice(0, 10)
      .map((c) => c.content)
      .join("\n\n");

    let parsedTopics: { name: string; subtopics: string[] }[] = [];

    if (hasGeminiKey()) {
      try {
        const prompt = `
Extract a structured academic hierarchy from this course material. 
Group into 3 to 6 major topics, each with 2 to 4 key subtopics.
Return strictly JSON matching this structure:
{
  "topics": [
    { "name": "Topic Name", "subtopics": ["Subtopic A", "Subtopic B"] }
  ]
}

Course Material:
${contextText.slice(0, 10000)}
`;
        const text = await generateStructuredText(prompt);
        const parsed = TopicTreeSchema.parse(JSON.parse(text));
        parsedTopics = parsed.topics;
      } catch (aiErr) {
        console.warn("AI topic extraction failed, using heuristic extraction:", aiErr);
      }
    }

    if (parsedTopics.length === 0) {
      // Heuristic fallback from section labels and content
      const sections = Array.from(new Set(userChunks.map((c) => c.section_label).filter(Boolean)));
      if (sections.length > 0) {
        parsedTopics = sections.slice(0, 5).map((sec) => ({
          name: sec.replace(/^(Chapter|Unit|Section|\d+\.|\#+)\s*/i, ""),
          subtopics: ["Key Concepts", "Core Implementations", "Applications"],
        }));
      } else {
        parsedTopics = [
          { name: "Foundational Principles", subtopics: ["Definitions & Invariants", "Base Properties"] },
          { name: "Core Operations", subtopics: ["Traversal & Search", "Updates & Restructuring"] },
          { name: "Algorithmic Analysis", subtopics: ["Time Complexity", "Worst-case Guarantees"] },
        ];
      }
    }

    // Insert newly generated topics into db
    const insertedTopics: any[] = [];
    for (const t of parsedTopics) {
      const parentId = "top-" + Math.random().toString(36).substring(2, 9);
      const parentTopic = {
        id: parentId,
        user_id: userId,
        name: t.name,
        parent_id: null,
        created_at: new Date().toISOString(),
      };
      db.topics.push(parentTopic);
      insertedTopics.push(parentTopic);

      for (const sub of t.subtopics) {
        const childTopic = {
          id: "top-" + Math.random().toString(36).substring(2, 9),
          user_id: userId,
          name: sub,
          parent_id: parentId,
          created_at: new Date().toISOString(),
        };
        db.topics.push(childTopic);
        insertedTopics.push(childTopic);
      }
    }

    // Map unassigned chunks to closest topic using embedding similarity
    const unassignedChunks = db.chunks.filter((c) => c.user_id === userId && !c.topic_id);
    for (const chunk of unassignedChunks) {
      let bestTopicId: string | null = null;
      let highestSim = -1;

      for (const topic of insertedTopics) {
        const topicEmb = await generateEmbedding(topic.name);
        const sim = (await import("./server/gemini.js")).cosineSimilarity(topicEmb, chunk.embedding);
        if (sim > highestSim) {
          highestSim = sim;
          bestTopicId = topic.id;
        }
      }

      if (bestTopicId) {
        chunk.topic_id = bestTopicId;
      }
    }

    res.json({ success: true, count: insertedTopics.length });
  } catch (error: any) {
    console.error("Topic generation error:", error);
    res.status(500).json({ error: error.message || "Failed to generate topic tree" });
  }
});

// ==========================================
// QUIZ GENERATION & EVALUATION (RAG)
// ==========================================

app.post("/api/quiz/generate", async (req: Request, res: Response) => {
  try {
    const userId = resolveUserId(req);
    const userTopics = db.topics.filter((t) => t.user_id === userId);

    if (userTopics.length === 0) {
      return res.status(400).json({ error: "No topics found. Please generate topics first." });
    }

    // Create a new quiz attempt
    const attemptId = "att-" + Math.random().toString(36).substring(2, 9);
    const newAttempt = {
      id: attemptId,
      user_id: userId,
      score: 0,
      created_at: new Date().toISOString(),
    };
    db.quizAttempts.push(newAttempt);

    const questions: any[] = [];
    const topicsToTest = userTopics.slice(0, 5);

    // RETRIEVAL STEP: Fetch top chunks for all topics in parallel
    const topicContexts: {
      topic: any;
      topChunk: any;
      context: string;
    }[] = [];

    for (const topic of topicsToTest) {
      const topicEmb = await generateEmbedding(topic.name);
      const matched = db.matchChunks(topicEmb, 3, userId);
      if (matched.length > 0) {
        topicContexts.push({
          topic,
          topChunk: matched[0],
          context: matched
            .map((c) => `[Chunk ID: ${c.id}] Section: ${c.section_label || "Notes"}\nContent: ${c.content}`)
            .join("\n\n---\n\n"),
        });
      }
    }

    if (topicContexts.length === 0) {
      return res.status(400).json({ error: "No relevant content found in uploaded documents." });
    }

    const aiQuestionsByTopicId: Record<string, any> = {};

    if (hasGeminiKey()) {
      try {
        const batchPrompt = `
You are an unbending academic assessment engine.
Generate exactly 1 high-quality multiple-choice question for EACH of the following topics, derived SOLELY from their respective context chunks.
STRICT INSTRUCTION: Use ONLY the provided context chunks. If context is insufficient, omit outside knowledge.

Required JSON format:
{
  "questions": [
    {
      "topic_id": "Exact topic_id from below",
      "question": "Question text testing the specific topic?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct_answer": "Exact matching string of the correct option",
      "citation_quote": "Exact short quote from the chunk verifying the answer",
      "explanation": "Clear reason why this is correct based strictly on the text"
    }
  ]
}

Topics & Respective Context Chunks:
${topicContexts
  .map(
    (tc) => `### Topic: "${tc.topic.name}" [ID: ${tc.topic.id}]
Context:
${tc.context}`
  )
  .join("\n\n====================\n\n")}
`;

        const raw = await generateStructuredText(batchPrompt, undefined, 35000);
        const parsed = QuizQuestionsSchema.parse(JSON.parse(raw));
        for (const q of parsed.questions) {
          if (q.topic_id) {
            aiQuestionsByTopicId[q.topic_id] = q;
          }
        }
      } catch (e) {
        console.warn("Batch Gemini quiz generation note:", e);
      }
    }

    // Assemble final questions for all topics with grounded fallbacks
    for (const tc of topicContexts) {
      const topic = tc.topic;
      const topChunk = tc.topChunk;
      let generatedQ: any = null;

      const aiQ = aiQuestionsByTopicId[topic.id];
      if (aiQ && aiQ.options?.length >= 2 && aiQ.correct_answer) {
        generatedQ = {
          id: "qq-" + Math.random().toString(36).substring(2, 9),
          attempt_id: attemptId,
          topic_id: topic.id,
          topic_name: topic.name,
          question: aiQ.question,
          options: aiQ.options,
          correct_answer: aiQ.correct_answer,
          source_chunk_id: topChunk.id,
          citation_quote: aiQ.citation_quote || topChunk.content.slice(0, 120),
          explanation: aiQ.explanation,
          created_at: new Date().toISOString(),
        };
      }

      // Grounded fallback from top chunk if AI call timed out or omitted this topic
      if (!generatedQ) {
        const sentence = topChunk.content.split(". ")[0] + ".";
        generatedQ = {
          id: "qq-" + Math.random().toString(36).substring(2, 9),
          attempt_id: attemptId,
          topic_id: topic.id,
          topic_name: topic.name,
          question: `Based directly on your course material for "${topic.name}", which of the following is explicitly stated?`,
          options: [
            sentence,
            `The concept is not applicable to any real-world structures.`,
            `It behaves as an arbitrary queue with unbounded exponential runtime.`,
            `No formal definition exists within the provided notes.`,
          ],
          correct_answer: sentence,
          source_chunk_id: topChunk.id,
          citation_quote: sentence,
          explanation: `Directly supported by ${topChunk.section_label}: "${sentence}"`,
          created_at: new Date().toISOString(),
        };
      }

      db.quizQuestions.push(generatedQ);
      questions.push({
        ...generatedQ,
        source_chunk: {
          id: topChunk.id,
          section_label: topChunk.section_label,
          content: topChunk.content,
        },
      });
    }

    res.json({
      attemptId,
      questions,
    });
  } catch (error: any) {
    console.error("Quiz generate error:", error);
    res.status(500).json({ error: error.message || "Failed to generate quiz" });
  }
});

app.post("/api/quiz/evaluate", (req: Request, res: Response) => {
  try {
    const { questionId, userAnswer, attemptId } = req.body;
    const question = db.quizQuestions.find((q) => q.id === questionId);

    if (!question) {
      return res.status(404).json({ error: "Question not found" });
    }

    const isCorrect =
      question.correct_answer.trim().toLowerCase() === String(userAnswer).trim().toLowerCase();

    question.user_answer = userAnswer;
    question.is_correct = isCorrect;

    // Recalculate attempt score
    const allQuestions = db.quizQuestions.filter((q) => q.attempt_id === attemptId);
    const answered = allQuestions.filter((q) => q.is_correct !== undefined && q.is_correct !== null);

    if (answered.length > 0) {
      const correctCount = answered.filter((q) => q.is_correct).length;
      const scorePct = Math.round((correctCount / answered.length) * 100);
      const attempt = db.quizAttempts.find((a) => a.id === attemptId);
      if (attempt) {
        attempt.score = scorePct;
      }
    }

    const sourceChunk = db.chunks.find((c) => c.id === question.source_chunk_id);

    res.json({
      isCorrect,
      correctAnswer: question.correct_answer,
      explanation: question.explanation,
      citationQuote: question.citation_quote || (sourceChunk ? sourceChunk.content.slice(0, 150) : ""),
      sourceCitation: sourceChunk ? `Section: ${sourceChunk.section_label} (Page ${sourceChunk.page})` : "Course Notes",
    });
  } catch (error: any) {
    console.error("Quiz evaluation error:", error);
    res.status(500).json({ error: error.message || "Failed to evaluate question" });
  }
});

// ==========================================
// GAP ANALYSIS & REVISION PLAN
// ==========================================

app.get("/api/attempts", (req: Request, res: Response) => {
  const userId = resolveUserId(req);
  const attempts = db.quizAttempts
    .filter((a) => a.user_id === userId)
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

  res.json({ attempts });
});

app.post("/api/plan/generate", async (req: Request, res: Response) => {
  try {
    const userId = resolveUserId(req);
    const { attemptId, daysAvailable = 5, hoursPerDay = 3 } = req.body;

    // Look for target attempt or latest attempt
    let targetAttempt = db.quizAttempts.find((a) => a.id === attemptId);
    if (!targetAttempt) {
      const userAttempts = db.quizAttempts.filter((a) => a.user_id === userId);
      targetAttempt = userAttempts[userAttempts.length - 1];
    }

    if (!targetAttempt) {
      return res.status(400).json({ error: "No completed quiz attempt found. Take a quiz first." });
    }

    const questions = db.quizQuestions.filter((q) => q.attempt_id === targetAttempt.id);

    // Compute per-topic score: Strong >= 75%, Medium 40-74%, Weak < 40%
    const topicStats: Record<string, { name: string; total: number; correct: number }> = {};

    questions.forEach((q) => {
      const topic = db.topics.find((t) => t.id === q.topic_id);
      const name = topic ? topic.name : "Core Topic";
      if (!topicStats[q.topic_id]) {
        topicStats[q.topic_id] = { name, total: 0, correct: 0 };
      }
      topicStats[q.topic_id].total += 1;
      if (q.is_correct) topicStats[q.topic_id].correct += 1;
    });

    // If no questions in this attempt, fallback to existing topic scores or topics
    let gaps: any[] = [];
    if (Object.keys(topicStats).length === 0) {
      const existingScores = db.topicScores.filter((s) => s.user_id === userId);
      if (existingScores.length > 0) {
        gaps = existingScores.map((s) => {
          const t = db.topics.find((tp) => tp.id === s.topic_id);
          return {
            topic_id: s.topic_id,
            topic_name: t?.name || "Topic",
            score: s.score,
            category: s.category,
            reason: s.reason,
          };
        });
      } else {
        const userTopics = db.topics.filter((t) => t.user_id === userId).slice(0, 4);
        gaps = userTopics.map((t, idx) => ({
          topic_id: t.id,
          topic_name: t.name,
          score: idx === 0 ? 80 : idx === 1 ? 55 : 25,
          category: idx === 0 ? "strong" : idx === 1 ? "medium" : "weak",
          reason: idx === 0 ? "Solid theoretical recall." : idx === 1 ? "Good foundation with minor edge-case gaps." : "Requires focused remediation.",
        }));
      }
    } else {
      gaps = Object.entries(topicStats).map(([topicId, stats]) => {
        const pct = Math.round((stats.correct / stats.total) * 100);
        let category: "weak" | "medium" | "strong" = "medium";
        if (pct < 40) category = "weak";
        else if (pct >= 75) category = "strong";

        let reason = "";
        if (category === "weak") {
          reason = `Struggled with core definitions and invariants under ${stats.name}.`;
        } else if (category === "medium") {
          reason = `Understands foundational rules, but missed boundary condition questions.`;
        } else {
          reason = `Excellent grasp of the core concepts and source text citations.`;
        }

        return {
          topic_id: topicId,
          topic_name: stats.name,
          score: pct,
          category,
          reason,
        };
      });
    }

    // Save individual topic scores
    for (const g of gaps) {
      db.topicScores.push({
        id: "ts-" + Math.random().toString(36).substring(2, 9),
        user_id: userId,
        topic_id: g.topic_id,
        attempt_id: targetAttempt.id,
        score: g.score,
        category: g.category,
        reason: g.reason,
        created_at: new Date().toISOString(),
      });
    }

    // Generate revision schedule strictly allocating more time to weak areas (60%), medium (30%), strong (10%)
    let planSchedule: any[] = [];

    if (hasGeminiKey()) {
      try {
        const prompt = `
Create an optimal revision plan given:
Days available: ${daysAvailable}
Hours per day: ${hoursPerDay}

Student Topic Diagnostics:
${JSON.stringify(gaps, null, 2)}

Prioritization Rules:
- Weak topics MUST receive top priority and 60% of total schedule time.
- Medium topics receive 30% of total time.
- Strong topics receive light review (10%).

Return strictly JSON matching:
{
  "schedule": [
    {
      "day": 1,
      "theme": "Theme title",
      "allocated_hours": ${hoursPerDay},
      "tasks": [
        {
          "topic_name": "Topic Name",
          "category": "weak",
          "activity": "Specific practice exercise",
          "duration_minutes": 60
        }
      ]
    }
  ]
}
`;
        const raw = await generateStructuredText(prompt);
        const parsed = RevisionPlanSchema.parse(JSON.parse(raw));
        planSchedule = parsed.schedule;
      } catch (aiErr) {
        console.warn("AI plan generation failed, generating prioritized algorithmic plan:", aiErr);
      }
    }

    if (planSchedule.length === 0) {
      // Deterministic prioritization plan
      const weak = gaps.filter((g) => g.category === "weak");
      const med = gaps.filter((g) => g.category === "medium");
      const strong = gaps.filter((g) => g.category === "strong");

      for (let day = 1; day <= daysAvailable; day++) {
        const tasks: any[] = [];
        let theme = "Targeted Weak Area Remediation";

        if (day <= Math.ceil(daysAvailable * 0.6) && weak.length > 0) {
          theme = `Focus on High-Priority Gaps: ${weak[0].topic_name}`;
          tasks.push({
            topic_name: weak[0].topic_name,
            category: "weak",
            activity: `Re-read foundational section notes and trace 3 example problems.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.65),
          });
          if (weak[1] || med[0]) {
            const nextTarget = weak[1] || med[0];
            tasks.push({
              topic_name: nextTarget.topic_name,
              category: nextTarget.category,
              activity: `Concept check and flashcard review on edge cases.`,
              duration_minutes: Math.round(hoursPerDay * 60 * 0.35),
            });
          }
        } else if (day < daysAvailable && med.length > 0) {
          theme = `Medium Topic Strengthening & Mixed Practice`;
          tasks.push({
            topic_name: med[0]?.topic_name || "Applied Problems",
            category: "medium",
            activity: `Practice timed questions and review error logs.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.5),
          });
          if (weak.length > 0) {
            tasks.push({
              topic_name: weak[0].topic_name,
              category: "weak",
              activity: `Quick 30-min drill on weakest concept to lock in retention.`,
              duration_minutes: Math.round(hoursPerDay * 60 * 0.3),
            });
          }
          if (strong.length > 0) {
            tasks.push({
              topic_name: strong[0].topic_name,
              category: "strong",
              activity: `Speed review of strong topic invariants.`,
              duration_minutes: Math.round(hoursPerDay * 60 * 0.2),
            });
          }
        } else {
          theme = "Comprehensive Diagnostic Simulation & Exam Readiness";
          tasks.push({
            topic_name: "Mock Assessment",
            category: "weak",
            activity: `Retake GapFinder diagnostic quiz to confirm 0 weak topics remaining.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.5),
          });
          tasks.push({
            topic_name: "Explain-This-Topic Consultation",
            category: "medium",
            activity: `Use Grounded Assistant on any lingering doubts.`,
            duration_minutes: Math.round(hoursPerDay * 60 * 0.5),
          });
        }

        planSchedule.push({
          day,
          theme,
          allocated_hours: hoursPerDay,
          tasks,
        });
      }
    }

    const newPlan = {
      id: "plan-" + Math.random().toString(36).substring(2, 9),
      user_id: userId,
      days_available: daysAvailable,
      hours_per_day: hoursPerDay,
      plan_json: planSchedule,
      created_at: new Date().toISOString(),
    };
    db.revisionPlans.push(newPlan);

    res.json({
      success: true,
      plan: planSchedule,
      gaps,
      attemptId: targetAttempt.id,
    });
  } catch (error: any) {
    console.error("Plan generation error:", error);
    res.status(500).json({ error: error.message || "Failed to generate revision plan" });
  }
});

app.get("/api/plan/latest", (req: Request, res: Response) => {
  const userId = resolveUserId(req);
  const userPlans = db.revisionPlans.filter((p) => p.user_id === userId);
  const latestPlan = userPlans[userPlans.length - 1];

  const userScores = db.topicScores.filter((s) => s.user_id === userId);
  // Get unique latest score per topic
  const latestByTopic: Record<string, any> = {};
  for (const s of userScores) {
    const topic = db.topics.find((t) => t.id === s.topic_id);
    latestByTopic[s.topic_id] = {
      ...s,
      topic_name: topic?.name || "Topic",
    };
  }

  res.json({
    plan: latestPlan ? latestPlan.plan_json : null,
    daysAvailable: latestPlan?.days_available ?? 5,
    hoursPerDay: latestPlan?.hours_per_day ?? 3,
    gaps: Object.values(latestByTopic),
  });
});

// ==========================================
// EXPLAIN-THIS-TOPIC GROUNDED ASSISTANT
// ==========================================

app.post("/api/assistant", async (req: Request, res: Response) => {
  try {
    const userId = resolveUserId(req);
    const { query } = req.body;

    if (!query || !query.trim()) {
      return res.status(400).json({ error: "Query is required" });
    }

    const queryEmbedding = await generateEmbedding(query);
    // Retrieve top 4 chunks
    const matchedChunks = db.matchChunks(queryEmbedding, 4, userId);

    if (matchedChunks.length === 0) {
      return res.json({
        answer: "Not found in your material.",
        citations: [],
      });
    }

    // Similarity threshold check: If the top chunk similarity is too low, reject
    const topSimilarity = matchedChunks[0].similarity;
    if (topSimilarity < 0.15) {
      return res.json({
        answer: "Not found in your material. Your question does not match any concepts in your uploaded syllabus, notes, or exam papers.",
        citations: [],
      });
    }

    const context = matchedChunks
      .map((c) => `[Citation Source: ${c.section_label || "Notes"}] ${c.content}`)
      .join("\n\n");

    let answerText = "";

    if (hasGeminiKey()) {
      try {
        const prompt = `
Answer the student's question based SOLELY on the provided context chunks.
STRICT INSTRUCTION: If the context does not contain enough information to answer completely, respond: "Not found in your material."
Do not extrapolate or use outside knowledge. Cite the section names inline when stating facts.

Context Chunks:
${context}

Student Question:
${query}
`;
        answerText = await generateStructuredText(
          prompt,
          "You are an academic mentor answering solely from provided notes. If the text does not directly answer the question, reply strictly: Not found in your material."
        );
      } catch (err) {
        console.warn("Assistant Gemini call failed, generating fallback answer:", err);
      }
    }

    // Strict relevance verification against query keywords
    const queryTokens = query
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, "")
      .split(/\s+/)
      .filter((w: string) => w.length > 2 && !["what", "explain", "how", "the", "and", "can", "you", "does", "is", "are", "about", "tell"].includes(w));
    
    const relevantChunks = matchedChunks.filter((c) =>
      queryTokens.some((t: string) => c.content.toLowerCase().includes(t) || (c.section_label && c.section_label.toLowerCase().includes(t)))
    );

    if (relevantChunks.length === 0 && (!answerText || answerText.toLowerCase().includes("not found in your material"))) {
      return res.json({
        answer: "Not found in your material. This topic is not covered in your uploaded syllabus, notes, or exam papers.",
        citations: [],
      });
    }

    const citationsChunks = relevantChunks.length > 0 ? relevantChunks : matchedChunks;

    if (!answerText) {
      const topChunk = citationsChunks[0];
      answerText = `According to your material in "${topChunk.section_label}":\n\n${topChunk.content}\n\nKey takeaways: This concept is covered on Page ${topChunk.page} of your course notes.`;
    }

    const citations = citationsChunks.map((c) => ({
      section: c.section_label || "Uploaded Notes",
      page: c.page,
      snippet: c.content.slice(0, 160) + "...",
    }));

    res.json({
      answer: answerText,
      citations,
    });
  } catch (error: any) {
    console.error("Assistant error:", error);
    res.status(500).json({ error: error.message || "Failed to process query" });
  }
});

// ==========================================
// VITE SPA INTEGRATION
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, "dist", "index.html"));
    });
  }

  app.listen(port, "0.0.0.0", () => {
    console.log(`GapFinder AI server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
