import { GoogleGenAI, ThinkingLevel } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY || "";
export const defaultTextModel = process.env.GEMINI_MODEL || "gemini-3.8-flash";
export const defaultEmbedModel = process.env.GEMINI_EMBED_MODEL || "gemini-embedding-2-preview";

let aiInstance: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI {
  if (!apiKey) {
    throw new Error("Missing GEMINI_API_KEY environment variable.");
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

/**
 * Generate a 768-dim embedding vector using Gemini.
 * Explicitly sets outputDimensionality: 768 to match the PostgreSQL vector(768) column.
 * Throws a clear error if embedding fails (no fake hash fallback).
 */
export async function generateEmbedding(text: string): Promise<number[]> {
  const ai = getGeminiClient();
  const cleanedText = text.replace(/\n/g, " ").trim().slice(0, 4000);

  if (!cleanedText) {
    throw new Error("Cannot generate embedding for empty text content.");
  }

  try {
    const response = await ai.models.embedContent({
      model: defaultEmbedModel,
      contents: cleanedText,
      config: {
        outputDimensionality: 768,
      },
    });

    const values =
      response.embeddings?.[0]?.values || (response as any).embedding?.values;

    if (!values || values.length === 0) {
      throw new Error(`Embedding model (${defaultEmbedModel}) returned an empty vector.`);
    }

    return values;
  } catch (error: any) {
    throw new Error(`Gemini embedding failed for model "${defaultEmbedModel}": ${error.message}`);
  }
}

/**
 * Generate batch embeddings in parallel with batching to avoid API limits.
 */
export async function generateBatchEmbeddings(texts: string[], batchSize = 5): Promise<number[][]> {
  const results: number[][] = [];
  for (let i = 0; i < texts.length; i += batchSize) {
    const batch = texts.slice(i, i + batchSize);
    const batchResults = await Promise.all(
      batch.map((txt) => generateEmbedding(txt))
    );
    results.push(...batchResults);
  }
  return results;
}

/**
 * Generate structured text with ThinkingLevel.LOW and strict timeout so calls never hang.
 */
export async function generateStructuredTextWithTimeout(
  prompt: string,
  systemInstruction?: string,
  timeoutMs = 30000
): Promise<string> {
  const ai = getGeminiClient();

  const generatePromise = (async () => {
    const response = await ai.models.generateContent({
      model: defaultTextModel,
      contents: prompt,
      config: {
        temperature: 0.1,
        responseMimeType: "application/json",
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.LOW,
        },
        systemInstruction:
          systemInstruction ||
          "You are an academic assessment engine. Return only strict JSON matching the schema.",
      },
    });

    const text = response.text || "";
    return text.replace(/```json\n?|\n?```/g, "").trim();
  })();

  const timeoutPromise = new Promise<string>((_, reject) => {
    setTimeout(
      () =>
        reject(
          new Error(`Gemini request timed out after ${timeoutMs / 1000} seconds.`)
        ),
      timeoutMs
    );
  });

  return Promise.race([generatePromise, timeoutPromise]);
}

