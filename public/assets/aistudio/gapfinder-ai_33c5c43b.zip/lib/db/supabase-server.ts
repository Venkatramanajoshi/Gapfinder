import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";

const FALLBACK_URL = "https://placeholder-project.supabase.co";
const FALLBACK_KEY = "placeholder-anon-key-gapfinder-0000000000";

export function isSupabaseConfigured(): boolean {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  return Boolean(
    url &&
    key &&
    !url.includes("placeholder-project") &&
    !url.includes("your-project")
  );
}

export function createServerSupabase() {
  const cookieStore = cookies();

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || FALLBACK_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || FALLBACK_KEY;

  return createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value;
      },
      set(name: string, value: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value, ...options });
        } catch {
          // Can happen in Server Components (read-only cookie store)
        }
      },
      remove(name: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value: "", ...options });
        } catch {
          // Can happen in Server Components
        }
      },
    },
  });
}


/**
 * Validates the authenticated user from the server session cookie.

 * NEVER trusts client-supplied user IDs. Returns 401 if unauthenticated.
 */
export async function getAuthenticatedUser(supabase: ReturnType<typeof createServerSupabase>) {
  const cookieStore = cookies();
  const demoCookie = cookieStore.get("gapfinder_demo_session")?.value;

  if (demoCookie === "demo-user-123" || !isSupabaseConfigured()) {
    return {
      id: "demo-user-123",
      email: "demo@gapfinder.app",
      app_metadata: {},
      user_metadata: { full_name: "Demo Student" },
      aud: "authenticated",
      created_at: new Date().toISOString(),
    } as any;
  }

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    return null;
  }
  return user;
}

