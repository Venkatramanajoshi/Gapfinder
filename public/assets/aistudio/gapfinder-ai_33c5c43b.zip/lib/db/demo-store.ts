/**
 * In-memory / Fallback repository for Demo & Evaluation Mode.
 * Ensures the end-to-end user flow works seamlessly even before
 * external Supabase credentials are configured by judges.
 */

export interface DemoDocument {
  id: string;
  user_id: string;
  name: string;
  type: "syllabus" | "notes" | "past_paper";
  created_at: string;
}

export interface DemoChunk {
  id: string;
  document_id: string;
  user_id: string;
  content: string;
  section_label: string;
  page: number;
  topic_id: string | null;
  embedding?: number[];
}

export interface DemoTopic {
  id: string;
  user_id: string;
  name: string;
  parent_id: string | null;
}

export interface DemoQuizAttempt {
  id: string;
  user_id: string;
  score: number;
  created_at: string;
}

export interface DemoQuizQuestion {
  id: string;
  attempt_id: string;
  topic_id: string;
  question: string;
  options: string[];
  correct_answer: string;
  source_chunk_id: string;
  user_answer?: string | null;
  is_correct?: boolean | null;
  explanation: string;
  citation_quote?: string;
}

export interface DemoTopicScore {
  id: string;
  user_id: string;
  topic_id: string;
  attempt_id: string;
  score: number;
  reason: string;
}

export interface DemoRevisionPlan {
  id: string;
  user_id: string;
  days_available: number;
  hours_per_day: number;
  plan_json: any;
  created_at: string;
}

// Initial seed data
const initialDocs: DemoDocument[] = [
  {
    id: "doc-1",
    user_id: "demo-user-123",
    name: "CS 106B: Data Structures & Algorithms Syllabus",
    type: "syllabus",
    created_at: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
  },
  {
    id: "doc-2",
    user_id: "demo-user-123",
    name: "Lecture Notes: Graphs & Priority Queues",
    type: "notes",
    created_at: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
  },
  {
    id: "doc-3",
    user_id: "demo-user-123",
    name: "Midterm Exam Sample Questions",
    type: "past_paper",
    created_at: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
];

const initialTopics: DemoTopic[] = [
  { id: "top-1", user_id: "demo-user-123", name: "Data Structures & Memory", parent_id: null },
  { id: "top-1-1", user_id: "demo-user-123", name: "Pointers & Dynamic Memory", parent_id: "top-1" },
  { id: "top-1-2", user_id: "demo-user-123", name: "Hash Tables & Collision Resolution", parent_id: "top-1" },
  { id: "top-2", user_id: "demo-user-123", name: "Algorithmic Complexity", parent_id: null },
  { id: "top-2-1", user_id: "demo-user-123", name: "Big-O Asymptotics & Recurrences", parent_id: "top-2" },
  { id: "top-2-2", user_id: "demo-user-123", name: "Divide-and-Conquer Sorting", parent_id: "top-2" },
  { id: "top-3", user_id: "demo-user-123", name: "Graph Algorithms", parent_id: null },
  { id: "top-3-1", user_id: "demo-user-123", name: "Dijkstra's Shortest Path", parent_id: "top-3" },
  { id: "top-3-2", user_id: "demo-user-123", name: "Breadth-First & Depth-First Search", parent_id: "top-3" },
];

const initialChunks: DemoChunk[] = [
  {
    id: "chk-1",
    document_id: "doc-2",
    user_id: "demo-user-123",
    section_label: "Section 4.1: Dijkstra's Algorithm Invariants",
    page: 14,
    topic_id: "top-3-1",
    content: "Dijkstra's algorithm finds the shortest path between nodes in a graph with non-negative edge weights. The algorithm maintains a priority queue of vertices ordered by tentative distance from the source. A crucial invariant: when a vertex u is extracted from the min-heap, its tentative distance is guaranteed to be minimal and final. If edge weights can be negative, this greedy invariant fails, requiring the Bellman-Ford algorithm instead.",
  },
  {
    id: "chk-2",
    document_id: "doc-2",
    user_id: "demo-user-123",
    section_label: "Section 3.2: Hash Collision Resolution",
    page: 9,
    topic_id: "top-1-2",
    content: "In open addressing with linear probing, collisions are resolved by sequentially searching the hash table for the next available slot with formula h(k, i) = (h'(k) + i) mod m. While simple, linear probing suffers from primary clustering, where contiguous runs of occupied slots merge into larger clusters, degrading search and insertion times to O(n) in the worst case. Separate chaining avoids this clustering by maintaining linked lists at each bucket.",
  },
  {
    id: "chk-3",
    document_id: "doc-1",
    user_id: "demo-user-123",
    section_label: "Section 1.3: Dynamic Memory Management",
    page: 4,
    topic_id: "top-1-1",
    content: "Dynamic memory in C++ is allocated on the heap using the 'new' operator and must be explicitly deallocated using 'delete' (or 'delete[]' for arrays) to prevent memory leaks. A dangling pointer arises when memory is freed but the pointer variable is not cleared to nullptr, leading to undefined behavior if dereferenced later.",
  },
  {
    id: "chk-4",
    document_id: "doc-1",
    user_id: "demo-user-123",
    section_label: "Section 2.1: Master Theorem for Recurrences",
    page: 7,
    topic_id: "top-2-1",
    content: "The Master Theorem provides asymptotic bounds for divide-and-conquer recurrences of the form T(n) = a*T(n/b) + f(n), where a >= 1 and b > 1. If f(n) = O(n^(log_b(a) - epsilon)), the work is leaf-heavy and T(n) = Theta(n^(log_b(a))). For Merge Sort, a=2, b=2, and f(n)=O(n), resulting in the critical exponent log_2(2) = 1, leading to the balanced case T(n) = Theta(n log n).",
  },
  {
    id: "chk-5",
    document_id: "doc-2",
    user_id: "demo-user-123",
    section_label: "Section 5.3: BFS Properties",
    page: 18,
    topic_id: "top-3-2",
    content: "Breadth-First Search (BFS) explores vertices in order of their hop distance from the root vertex using a FIFO queue. In an unweighted graph, BFS computes the exact minimum number of edges needed to reach any reachable vertex. Its running time is O(V + E) when using an adjacency list representation.",
  },
];

const initialAttempts: DemoQuizAttempt[] = [
  {
    id: "att-1",
    user_id: "demo-user-123",
    score: 40,
    created_at: new Date(Date.now() - 3600000 * 48).toISOString(),
  },
  {
    id: "att-2",
    user_id: "demo-user-123",
    score: 65,
    created_at: new Date(Date.now() - 3600000 * 24).toISOString(),
  },
  {
    id: "att-3",
    user_id: "demo-user-123",
    score: 83,
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
];

const initialQuestions: DemoQuizQuestion[] = [
  {
    id: "q-1",
    attempt_id: "att-3",
    topic_id: "top-3-1",
    question: "Under what specific condition does the greedy invariant of Dijkstra's algorithm fail to guarantee optimal shortest paths?",
    options: [
      "When the graph contains negative edge weights",
      "When the graph has more than 1,000 vertices",
      "When using an adjacency matrix instead of an adjacency list",
      "When the source vertex has an indegree greater than zero",
    ],
    correct_answer: "When the graph contains negative edge weights",
    source_chunk_id: "chk-1",
    user_answer: "When using an adjacency matrix instead of an adjacency list",
    is_correct: false,
    explanation: "Dijkstra's greedy invariant assumes that once a vertex is extracted from the priority queue, no shorter path can be discovered later. Negative edge weights invalidate this guarantee.",
    citation_quote: "If edge weights can be negative, this greedy invariant fails, requiring the Bellman-Ford algorithm instead.",
  },
  {
    id: "q-2",
    attempt_id: "att-3",
    topic_id: "top-1-2",
    question: "What is the primary performance degradation caused by linear probing in open-addressed hash tables?",
    options: [
      "Primary clustering, where contiguous occupied slots degrade search time towards O(n)",
      "Instantaneous stack overflow from recursive hash re-evaluation",
      "Memory corruption due to cyclic pointer reallocation",
      "Inability to insert more than 16 keys regardless of table capacity",
    ],
    correct_answer: "Primary clustering, where contiguous occupied slots degrade search time towards O(n)",
    source_chunk_id: "chk-2",
    user_answer: "Primary clustering, where contiguous occupied slots degrade search time towards O(n)",
    is_correct: true,
    explanation: "Linear probing places colliding items into immediately adjacent cells, compounding run lengths into clusters that slow subsequent searches.",
    citation_quote: "linear probing suffers from primary clustering, where contiguous runs of occupied slots merge into larger clusters, degrading search and insertion times to O(n)",
  },
  {
    id: "q-3",
    attempt_id: "att-3",
    topic_id: "top-1-1",
    question: "What condition produces a dangling pointer in C++ dynamic memory management?",
    options: [
      "Memory is deallocated via delete, but the pointer is not set to nullptr and is accessed later",
      "A pointer is initialized directly to nullptr before any allocation takes place",
      "A stack variable is passed by constant reference to a helper function",
      "An array is allocated with new and freed with delete[]",
    ],
    correct_answer: "Memory is deallocated via delete, but the pointer is not set to nullptr and is accessed later",
    source_chunk_id: "chk-3",
    user_answer: "A pointer is initialized directly to nullptr before any allocation takes place",
    is_correct: false,
    explanation: "A dangling pointer points to a previously freed heap memory location. Subsequent dereferencing triggers undefined behavior.",
    citation_quote: "A dangling pointer arises when memory is freed but the pointer variable is not cleared to nullptr, leading to undefined behavior if dereferenced later.",
  },
  {
    id: "q-4",
    attempt_id: "att-3",
    topic_id: "top-2-1",
    question: "According to the Master Theorem, why does Merge Sort exhibit Theta(n log n) overall runtime?",
    options: [
      "The recurrence has a=2, b=2 with f(n)=O(n), placing it in the balanced case where log_b(a) = 1",
      "The recurrence is leaf-heavy with total work dominated strictly by the base cases",
      "The recurrence exhibits an exponential branching factor greater than the input size",
      "Merge Sort avoids divide-and-conquer and operates strictly in linear time",
    ],
    correct_answer: "The recurrence has a=2, b=2 with f(n)=O(n), placing it in the balanced case where log_b(a) = 1",
    source_chunk_id: "chk-4",
    user_answer: "The recurrence has a=2, b=2 with f(n)=O(n), placing it in the balanced case where log_b(a) = 1",
    is_correct: true,
    explanation: "With a=2 subproblems of size n/2 and linear merge cost f(n)=O(n), the critical exponent log_2(2)=1 matches f(n), yielding Theta(n log n).",
    citation_quote: "For Merge Sort, a=2, b=2, and f(n)=O(n), resulting in the critical exponent log_2(2) = 1, leading to the balanced case T(n) = Theta(n log n).",
  },
  {
    id: "q-5",
    attempt_id: "att-3",
    topic_id: "top-3-2",
    question: "What data structure guarantees that Breadth-First Search (BFS) computes shortest paths in unweighted graphs?",
    options: [
      "A First-In, First-Out (FIFO) queue",
      "A Last-In, First-Out (LIFO) call stack",
      "A self-balancing AVL search tree",
      "A priority queue sorted by ascending edge weight",
    ],
    correct_answer: "A First-In, First-Out (FIFO) queue",
    source_chunk_id: "chk-5",
    user_answer: "A First-In, First-Out (FIFO) queue",
    is_correct: true,
    explanation: "BFS uses a FIFO queue so that all vertices at distance k are processed before vertices at distance k+1.",
    citation_quote: "Breadth-First Search (BFS) explores vertices in order of their hop distance from the root vertex using a FIFO queue.",
  },
];

const initialTopicScores: DemoTopicScore[] = [
  {
    id: "ts-1",
    user_id: "demo-user-123",
    topic_id: "top-3-1",
    attempt_id: "att-3",
    score: 25,
    reason: "Struggles with invariant boundaries when non-standard edge weights (negative cycles) are present.",
  },
  {
    id: "ts-2",
    user_id: "demo-user-123",
    topic_id: "top-1-1",
    attempt_id: "att-3",
    score: 50,
    reason: "Understands heap allocation syntax, but confused dangling pointers with null pointer initialization.",
  },
  {
    id: "ts-3",
    user_id: "demo-user-123",
    topic_id: "top-1-2",
    attempt_id: "att-3",
    score: 100,
    reason: "Flawless grasp of open addressing hash collision mechanisms and primary clustering effects.",
  },
  {
    id: "ts-4",
    user_id: "demo-user-123",
    topic_id: "top-2-1",
    attempt_id: "att-3",
    score: 100,
    reason: "Mastered Master Theorem critical exponents and recurrence analysis.",
  },
  {
    id: "ts-5",
    user_id: "demo-user-123",
    topic_id: "top-3-2",
    attempt_id: "att-3",
    score: 100,
    reason: "Accurately identified FIFO queue mechanics for unweighted shortest paths.",
  },
];

const initialPlan: DemoRevisionPlan = {
  id: "plan-1",
  user_id: "demo-user-123",
  days_available: 5,
  hours_per_day: 3,
  created_at: new Date().toISOString(),
  plan_json: [
    {
      day: 1,
      theme: "Targeted Weak Topic Remediation: Dijkstra's Algorithm",
      allocated_hours: 3,
      tasks: [
        {
          topic_name: "Dijkstra's Shortest Path",
          category: "weak",
          activity: "Trace 3 example graphs with priority queue state transitions; identify why negative edge weights break greedy choice.",
          duration_minutes: 120,
        },
        {
          topic_name: "Pointers & Dynamic Memory",
          category: "medium",
          activity: "Review section 1.3 on heap lifecycle and dangling pointer traps.",
          duration_minutes: 60,
        },
      ],
    },
    {
      day: 2,
      theme: "Weak Topic Mastery & Edge-Case Drill",
      allocated_hours: 3,
      tasks: [
        {
          topic_name: "Dijkstra's Shortest Path",
          category: "weak",
          activity: "Compare Dijkstra vs Bellman-Ford complexity and solve 2 past paper questions.",
          duration_minutes: 120,
        },
        {
          topic_name: "Pointers & Dynamic Memory",
          category: "medium",
          activity: "Write dynamic array resizing routine verifying valgrind zero leaks.",
          duration_minutes: 60,
        },
      ],
    },
    {
      day: 3,
      theme: "Medium Topic Consolidation",
      allocated_hours: 3,
      tasks: [
        {
          topic_name: "Pointers & Dynamic Memory",
          category: "medium",
          activity: "Drill pointer arithmetic and destructor invariants in linked structures.",
          duration_minutes: 120,
        },
        {
          topic_name: "Hash Tables & Collision Resolution",
          category: "strong",
          activity: "Speed-review linear probing vs quadratic probing cluster equations.",
          duration_minutes: 60,
        },
      ],
    },
    {
      day: 4,
      theme: "Mixed Concept Synthesis & Medium Topics",
      allocated_hours: 3,
      tasks: [
        {
          topic_name: "Dijkstra's Shortest Path",
          category: "weak",
          activity: "Timed re-test on priority queue invariants and graph representations.",
          duration_minutes: 80,
        },
        {
          topic_name: "Big-O Asymptotics & Recurrences",
          category: "strong",
          activity: "Quick Master Theorem case 1-3 flash review.",
          duration_minutes: 40,
        },
        {
          topic_name: "Breadth-First & Depth-First Search",
          category: "strong",
          activity: "Verify BFS traversal invariants on directed graphs.",
          duration_minutes: 60,
        },
      ],
    },
    {
      day: 5,
      theme: "Comprehensive Simulation & Readiness Verification",
      allocated_hours: 3,
      tasks: [
        {
          topic_name: "Diagnostic Retake",
          category: "weak",
          activity: "Retake GapFinder diagnostic quiz to verify 0 weak topics remaining.",
          duration_minutes: 90,
        },
        {
          topic_name: "Explain-This-Topic Consultation",
          category: "medium",
          activity: "Consult Grounded Assistant on any lingering doubts.",
          duration_minutes: 90,
        },
      ],
    },
  ],
};

// Singleton store in memory
class DemoStore {
  documents: DemoDocument[] = [...initialDocs];
  chunks: DemoChunk[] = [...initialChunks];
  topics: DemoTopic[] = [...initialTopics];
  attempts: DemoQuizAttempt[] = [...initialAttempts];
  questions: DemoQuizQuestion[] = [...initialQuestions];
  topicScores: DemoTopicScore[] = [...initialTopicScores];
  revisionPlans: DemoRevisionPlan[] = [{ ...initialPlan }];

  reset() {
    this.documents = [...initialDocs];
    this.chunks = [...initialChunks];
    this.topics = [...initialTopics];
    this.attempts = [...initialAttempts];
    this.questions = [...initialQuestions];
    this.topicScores = [...initialTopicScores];
    this.revisionPlans = [{ ...initialPlan }];
  }
}

declare global {
  var __demoStoreInstance: DemoStore | undefined;
}

export const demoStore: DemoStore =
  globalThis.__demoStoreInstance || (globalThis.__demoStoreInstance = new DemoStore());
