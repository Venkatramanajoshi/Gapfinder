import { GoogleGenAI } from "@google/genai";

function isValidApiKey(key: string | undefined): boolean {
  return Boolean(
    key &&
    key.length > 10 &&
    key !== "MY_GEMINI_API_KEY" &&
    !key.includes("YOUR_")
  );
}

const rawApiKey = process.env.GEMINI_API_KEY || "";
const hasValidKey = isValidApiKey(rawApiKey);
let ai: GoogleGenAI | null = null;

if (hasValidKey) {
  ai = new GoogleGenAI({
    apiKey: rawApiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

/**
 * Generate a deterministic 768-dim pseudo embedding for local/fallback use
 */
function createFallbackEmbedding(text: string): number[] {
  const dim = 768;
  const vector = new Array(dim).fill(0);
  const normalized = text.toLowerCase().replace(/[^a-z0-9\s]/g, "");
  const words = normalized.split(/\s+/).filter(Boolean);

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    let hash = 0;
    for (let c = 0; c < word.length; c++) {
      hash = (hash << 5) - hash + word.charCodeAt(c);
      hash |= 0;
    }
    const idx = Math.abs(hash) % dim;
    const sign = (hash & 1) === 0 ? 1 : -1;
    vector[idx] += sign * (1 / (1 + (i % 5)));
  }

  // Normalize vector to unit length
  const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0)) || 1;
  return vector.map((v) => v / norm);
}

/**
 * Generates an embedding vector using gemini-embedding-2-preview with fallback
 */
export async function generateEmbedding(text: string): Promise<number[]> {
  if (ai) {
    try {
      const response = await ai.models.embedContent({
        model: "gemini-embedding-2-preview",
        contents: text.slice(0, 2048),
      });
      const values =
        response.embeddings?.[0]?.values || (response as any).embedding?.values;
      if (values && values.length > 0) {
        return values;
      }
    } catch (err) {
      console.warn("Gemini embedding API call failed, falling back to local embedding:", err);
    }
  }
  return createFallbackEmbedding(text);
}

/**
 * Calculate Cosine Similarity between two numeric vectors
 */
export function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Generate structured text using gemini-3.8-flash
 */
export async function generateStructuredText(
  prompt: string,
  systemInstruction?: string,
  timeoutMs = 35000
): Promise<string> {
  if (!ai) {
    throw new Error("GEMINI_API_KEY is not configured.");
  }

  const callPromise = ai.models.generateContent({
    model: "gemini-3.8-flash",
    contents: prompt,
    config: {
      temperature: 0.1,
      systemInstruction: systemInstruction || "You are an unbending academic assessment engine. You follow strict rules, cite provided sources, and produce valid JSON only.",
    },
  });

  const timeoutPromise = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error(`Gemini API call timed out after ${Math.round(timeoutMs / 1000)}s`)), timeoutMs)
  );

  const response = await Promise.race([callPromise, timeoutPromise]);
  const text = response.text || "";
  return text.replace(/```json\n?|\n?```/g, "").trim();
}

export function hasGeminiKey(): boolean {
  return hasValidKey;
}
