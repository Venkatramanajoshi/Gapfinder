import { cosineSimilarity, generateEmbedding } from "./gemini.js";

export interface Profile {
  id: string;
  email: string;
  created_at: string;
}

export interface Document {
  id: string;
  user_id: string;
  name: string;
  type: "syllabus" | "notes" | "past_paper";
  created_at: string;
}

export interface Topic {
  id: string;
  user_id: string;
  name: string;
  parent_id: string | null;
  created_at: string;
}

export interface Chunk {
  id: string;
  document_id: string;
  user_id: string;
  content: string;
  section_label: string;
  page: number;
  topic_id: string | null;
  embedding: number[];
  created_at: string;
}

export interface QuizAttempt {
  id: string;
  user_id: string;
  score: number;
  created_at: string;
}

export interface QuizQuestion {
  id: string;
  attempt_id: string;
  topic_id: string;
  question: string;
  options: string[];
  correct_answer: string;
  source_chunk_id?: string;
  user_answer?: string | null;
  is_correct?: boolean | null;
  explanation: string;
  citation_quote?: string;
  created_at: string;
}

export interface TopicScore {
  id: string;
  user_id: string;
  topic_id: string;
  attempt_id: string;
  score: number;
  category: "weak" | "medium" | "strong";
  reason: string;
  created_at: string;
}

export interface RevisionPlan {
  id: string;
  user_id: string;
  days_available: number;
  hours_per_day: number;
  plan_json: any;
  created_at: string;
}

// In-memory Database Store
class Database {
  profiles: Profile[] = [];
  documents: Document[] = [];
  topics: Topic[] = [];
  chunks: Chunk[] = [];
  quizAttempts: QuizAttempt[] = [];
  quizQuestions: QuizQuestion[] = [];
  topicScores: TopicScore[] = [];
  revisionPlans: RevisionPlan[] = [];

  constructor() {
    this.seedDemoUser();
  }

  findProfileByEmail(email: string): Profile | undefined {
    return this.profiles.find((p) => p.email.toLowerCase() === email.toLowerCase());
  }

  createProfile(email: string): Profile {
    const existing = this.findProfileByEmail(email);
    if (existing) return existing;
    const profile: Profile = {
      id: "usr-" + Math.random().toString(36).substring(2, 10),
      email,
      created_at: new Date().toISOString(),
    };
    this.profiles.push(profile);
    return profile;
  }

  matchChunks(
    queryEmbedding: number[],
    matchCount: number,
    filterUserId: string,
    filterTopicId?: string
  ): (Chunk & { similarity: number })[] {
    const userChunks = this.chunks.filter((c) => c.user_id === filterUserId);
    const scored = userChunks
      .filter((c) => (!filterTopicId ? true : c.topic_id === filterTopicId))
      .map((chunk) => ({
        ...chunk,
        similarity: cosineSimilarity(queryEmbedding, chunk.embedding),
      }));

    scored.sort((a, b) => b.similarity - a.similarity);
    return scored.slice(0, matchCount);
  }

  async seedDemoUser() {
    const demoEmail = "demo@gapfinder.app";
    const existing = this.findProfileByEmail(demoEmail);
    const user = existing || this.createProfile(demoEmail);

    // If already seeded with documents, skip re-seeding
    if (this.documents.some((d) => d.user_id === user.id)) {
      return;
    }

    const now = new Date().toISOString();

    // 1. Documents (Syllabus, Notes, Past Paper)
    const syllabusDoc: Document = {
      id: "doc-syllabus-1",
      user_id: user.id,
      name: "CS201 Syllabus: Data Structures & Algorithms",
      type: "syllabus",
      created_at: now,
    };
    const notesDoc: Document = {
      id: "doc-notes-1",
      user_id: user.id,
      name: "Prof. Miller - DSA Lecture Notes (Units 1-4)",
      type: "notes",
      created_at: now,
    };
    const examDoc: Document = {
      id: "doc-pastpaper-1",
      user_id: user.id,
      name: "Midterm Exam 2024 - Solved Questions",
      type: "past_paper",
      created_at: now,
    };

    this.documents.push(syllabusDoc, notesDoc, examDoc);

    // 2. Topics Hierarchy
    const tTree: { id: string; name: string; parent_id: string | null }[] = [
      { id: "top-trees", name: "Tree Structures", parent_id: null },
      { id: "top-bst", name: "Binary Search Trees & Balancing", parent_id: "top-trees" },
      { id: "top-avl", name: "AVL & Red-Black Trees", parent_id: "top-trees" },
      { id: "top-graphs", name: "Graph Algorithms", parent_id: null },
      { id: "top-traversal", name: "Breadth-First & Depth-First Search", parent_id: "top-graphs" },
      { id: "top-dijkstra", name: "Shortest Path & Dijkstra", parent_id: "top-graphs" },
      { id: "top-dp", name: "Dynamic Programming", parent_id: null },
      { id: "top-dp-memo", name: "Memoization vs Tabulation", parent_id: "top-dp" },
      { id: "top-dp-knapsack", name: "0/1 Knapsack & Subsequence Problems", parent_id: "top-dp" },
      { id: "top-hashing", name: "Hash Tables & Collision Resolution", parent_id: null },
    ];

    for (const t of tTree) {
      this.topics.push({
        id: t.id,
        user_id: user.id,
        name: t.name,
        parent_id: t.parent_id,
        created_at: now,
      });
    }

    // 3. Grounded Chunks with real quotes and section references
    const rawChunks = [
      {
        id: "chk-1",
        docId: syllabusDoc.id,
        section: "Syllabus Unit 1: Binary Search Trees",
        text: "Binary Search Trees (BST) enforce the fundamental ordering property: for any given node with key K, all keys in its left subtree are strictly less than K, and all keys in its right subtree are strictly greater than K. An inorder traversal (Left-Root-Right) on a valid BST always prints all elements in strictly ascending sorted order.",
        topicId: "top-bst",
        page: 1,
      },
      {
        id: "chk-2",
        docId: notesDoc.id,
        section: "Lecture 4: Self-Balancing Trees",
        text: "AVL Trees are self-balancing binary search trees where the heights of the two child subtrees of any node differ by at most 1 (Balance Factor = Height(Left) - Height(Right) in {-1, 0, 1}). If balance is violated after insertion or deletion, rotation operations (Left Rotation, Right Rotation, Left-Right, Right-Left) restore O(log n) worst-case search time.",
        topicId: "top-avl",
        page: 4,
      },
      {
        id: "chk-3",
        docId: notesDoc.id,
        section: "Lecture 7: Graph Traversals (BFS vs DFS)",
        text: "Breadth-First Search (BFS) traverses a graph level by level from the source vertex. BFS requires a First-In-First-Out (FIFO) queue data structure to track frontier vertices, guaranteeing shortest path finding in unweighted graphs. In contrast, Depth-First Search (DFS) explores as deep as possible along each branch before backtracking, using a Last-In-First-Out (LIFO) stack or recursion. The time complexity for both traversals using an adjacency list is O(V + E).",
        topicId: "top-traversal",
        page: 8,
      },
      {
        id: "chk-4",
        docId: examDoc.id,
        section: "Midterm 2024 Question 3: Dynamic Programming Concepts",
        text: "Dynamic Programming (DP) is applicable only when a problem exhibits both Optimal Substructure and Overlapping Subproblems. Memoization is a top-down approach that caches results of recursive calls in a hash table or array. Tabulation is a bottom-up approach that iteratively solves all subproblems starting from base cases and fills an n-dimensional table.",
        topicId: "top-dp-memo",
        page: 2,
      },
      {
        id: "chk-5",
        docId: notesDoc.id,
        section: "Lecture 11: 0/1 Knapsack Problem",
        text: "In the 0/1 Knapsack problem, items cannot be broken into fractions. Given capacity W and n items with values v_i and weights w_i, the recurrence relation is: DP[i][w] = DP[i-1][w] if w_i > w, else max(DP[i-1][w], v_i + DP[i-1][w - w_i]). The dynamic programming state table requires O(n * W) time and space complexity.",
        topicId: "top-dp-knapsack",
        page: 14,
      },
      {
        id: "chk-6",
        docId: notesDoc.id,
        section: "Lecture 3: Hash Tables & Open Addressing",
        text: "Hash Tables provide expected O(1) average lookup time. When hash collisions occur, two main paradigms exist: Separate Chaining (each bucket holds a linked list) and Open Addressing (probing inside the array). Linear Probing searches subsequent slots with index (hash(k) + i) % m, which is susceptible to primary clustering.",
        topicId: "top-hashing",
        page: 5,
      },
    ];

    for (const c of rawChunks) {
      const emb = await generateEmbedding(c.text);
      this.chunks.push({
        id: c.id,
        document_id: c.docId,
        user_id: user.id,
        content: c.text,
        section_label: c.section,
        page: c.page,
        topic_id: c.topicId,
        embedding: emb,
        created_at: now,
      });
    }

    // 4. Past Quiz Attempts (Showing progress across 3 attempts)
    const att1: QuizAttempt = {
      id: "att-001",
      user_id: user.id,
      score: 38.0,
      created_at: new Date(Date.now() - 4 * 86400000).toISOString(),
    };
    const att2: QuizAttempt = {
      id: "att-002",
      user_id: user.id,
      score: 55.0,
      created_at: new Date(Date.now() - 2 * 86400000).toISOString(),
    };
    const att3: QuizAttempt = {
      id: "att-003",
      user_id: user.id,
      score: 72.5,
      created_at: new Date(Date.now() - 3600000).toISOString(),
    };

    this.quizAttempts.push(att1, att2, att3);

    // 5. Quiz Questions for Attempt 3
    const q1: QuizQuestion = {
      id: "qq-1",
      attempt_id: att3.id,
      topic_id: "top-bst",
      question: "Which traversal of a valid Binary Search Tree is guaranteed to visit all node keys in strictly ascending sorted order?",
      options: ["Preorder (Root-Left-Right)", "Inorder (Left-Root-Right)", "Postorder (Left-Right-Root)", "Level-order (BFS)"],
      correct_answer: "Inorder (Left-Root-Right)",
      source_chunk_id: "chk-1",
      user_answer: "Inorder (Left-Root-Right)",
      is_correct: true,
      explanation: "Per the syllabus section on BST ordering properties: An inorder traversal (Left-Root-Right) on a valid BST always prints all elements in strictly ascending sorted order.",
      citation_quote: "An inorder traversal (Left-Root-Right) on a valid BST always prints all elements in strictly ascending sorted order.",
      created_at: now,
    };

    const q2: QuizQuestion = {
      id: "qq-2",
      attempt_id: att3.id,
      topic_id: "top-traversal",
      question: "According to the course notes, what primary data structure does Breadth-First Search (BFS) utilize to maintain its traversal frontier, and what does it guarantee in unweighted graphs?",
      options: ["LIFO Stack, guarantees cycle detection", "FIFO Queue, guarantees shortest path finding", "Priority Queue, guarantees minimum spanning tree", "Recursive call stack, guarantees topological sort"],
      correct_answer: "FIFO Queue, guarantees shortest path finding",
      source_chunk_id: "chk-3",
      user_answer: "LIFO Stack, guarantees cycle detection",
      is_correct: false,
      explanation: "Incorrect. BFS requires a First-In-First-Out (FIFO) queue data structure to track frontier vertices and guarantees shortest path finding in unweighted graphs. LIFO stacks are used by Depth-First Search (DFS).",
      citation_quote: "BFS requires a First-In-First-Out (FIFO) queue data structure to track frontier vertices, guaranteeing shortest path finding in unweighted graphs.",
      created_at: now,
    };

    const q3: QuizQuestion = {
      id: "qq-3",
      attempt_id: att3.id,
      topic_id: "top-dp-memo",
      question: "What key distinction does the midterm exam review make between Memoization and Tabulation in Dynamic Programming?",
      options: [
        "Memoization is top-down caching of recursive calls, whereas Tabulation is bottom-up iterative table filling",
        "Memoization uses O(n!) permutations, while Tabulation requires greedy selection",
        "Memoization is strictly iterative, while Tabulation relies on recursion",
        "Memoization applies only to trees, while Tabulation applies only to graphs"
      ],
      correct_answer: "Memoization is top-down caching of recursive calls, whereas Tabulation is bottom-up iterative table filling",
      source_chunk_id: "chk-4",
      user_answer: "Memoization is strictly iterative, while Tabulation relies on recursion",
      is_correct: false,
      explanation: "Incorrect. Midterm Question 3 specifies: Memoization is a top-down approach that caches results of recursive calls. Tabulation is a bottom-up approach that iteratively solves all subproblems.",
      citation_quote: "Memoization is a top-down approach that caches results of recursive calls in a hash table or array. Tabulation is a bottom-up approach that iteratively solves all subproblems.",
      created_at: now,
    };

    const q4: QuizQuestion = {
      id: "qq-4",
      attempt_id: att3.id,
      topic_id: "top-hashing",
      question: "In open addressing hash tables, what collision resolution technique computes slot index using (hash(k) + i) % m and suffers from primary clustering?",
      options: ["Separate Chaining", "Linear Probing", "Double Hashing", "Consistent Hashing"],
      correct_answer: "Linear Probing",
      source_chunk_id: "chk-6",
      user_answer: "Linear Probing",
      is_correct: true,
      explanation: "Correct. Lecture 3 states that Linear Probing searches subsequent slots with index (hash(k) + i) % m, which is susceptible to primary clustering.",
      citation_quote: "Linear Probing searches subsequent slots with index (hash(k) + i) % m, which is susceptible to primary clustering.",
      created_at: now,
    };

    this.quizQuestions.push(q1, q2, q3, q4);

    // 6. Topic Scores (Gaps: Weak < 40%, Medium 40-74%, Strong >= 75%)
    this.topicScores.push(
      {
        id: "ts-1",
        user_id: user.id,
        topic_id: "top-bst",
        attempt_id: att3.id,
        score: 100,
        category: "strong",
        reason: "Flawless grasp of Binary Search Tree ordering invariants and traversal mechanisms.",
        created_at: now,
      },
      {
        id: "ts-2",
        user_id: user.id,
        topic_id: "top-hashing",
        attempt_id: att3.id,
        score: 75,
        category: "strong",
        reason: "Strong understanding of open addressing and collision resolution strategies.",
        created_at: now,
      },
      {
        id: "ts-3",
        user_id: user.id,
        topic_id: "top-avl",
        attempt_id: att3.id,
        score: 50,
        category: "medium",
        reason: "Understands AVL balance factors but needs reinforcement on double rotations (LR/RL).",
        created_at: now,
      },
      {
        id: "ts-4",
        user_id: user.id,
        topic_id: "top-traversal",
        attempt_id: att3.id,
        score: 25,
        category: "weak",
        reason: "Confounded FIFO queue BFS mechanics with LIFO DFS stack backtracking semantics.",
        created_at: now,
      },
      {
        id: "ts-5",
        user_id: user.id,
        topic_id: "top-dp-memo",
        attempt_id: att3.id,
        score: 20,
        category: "weak",
        reason: "Struggles to differentiate top-down recursive memoization from bottom-up iterative DP tabulation.",
        created_at: now,
      }
    );

    // 7. Initial Revision Plan (Weak topics prioritized: 60% of total time)
    this.revisionPlans.push({
      id: "plan-001",
      user_id: user.id,
      days_available: 5,
      hours_per_day: 3,
      plan_json: [
        {
          day: 1,
          theme: "Deep Dive: Graph Traversal Mechanisms",
          allocated_hours: 3,
          tasks: [
            {
              topic_name: "Breadth-First & Depth-First Search",
              category: "weak",
              activity: "Trace BFS queue state on an unweighted 6-node graph. Contrast with recursive DFS call stack.",
              duration_minutes: 100,
            },
            {
              topic_name: "Breadth-First & Depth-First Search",
              category: "weak",
              activity: "Solve Midterm practice question: BFS shortest-path distance recording.",
              duration_minutes: 80,
            },
          ],
        },
        {
          day: 2,
          theme: "Dynamic Programming Foundations: Top-Down vs Bottom-Up",
          allocated_hours: 3,
          tasks: [
            {
              topic_name: "Memoization vs Tabulation",
              category: "weak",
              activity: "Implement Fibonacci and 0/1 Knapsack recursively with memoization, then rewrite using DP table.",
              duration_minutes: 110,
            },
            {
              topic_name: "0/1 Knapsack & Subsequence Problems",
              category: "weak",
              activity: "Work through Lecture 11 recurrence relation and fill out 2D capacity state matrix.",
              duration_minutes: 70,
            },
          ],
        },
        {
          day: 3,
          theme: "Consolidation & Tree Balancing",
          allocated_hours: 3,
          tasks: [
            {
              topic_name: "AVL & Red-Black Trees",
              category: "medium",
              activity: "Draw single Right/Left rotations and complex Left-Right double rotations after insertion.",
              duration_minutes: 80,
            },
            {
              topic_name: "Memoization vs Tabulation",
              category: "weak",
              activity: "Diagnostic re-check on DP state transitions and edge boundary conditions.",
              duration_minutes: 70,
            },
            {
              topic_name: "Tree Structures",
              category: "strong",
              activity: "Speed run 5 BST inorder traversal and search complexity problems.",
              duration_minutes: 30,
            },
          ],
        },
        {
          day: 4,
          theme: "Hash Tables & Mixed Problem Practice",
          allocated_hours: 3,
          tasks: [
            {
              topic_name: "Hash Tables & Collision Resolution",
              category: "strong",
              activity: "Review open addressing vs separate chaining and linear probing primary clustering.",
              duration_minutes: 45,
            },
            {
              topic_name: "Graph Algorithms",
              category: "weak",
              activity: "Simulate Dijkstra vs BFS on weighted vs unweighted graphs.",
              duration_minutes: 85,
            },
            {
              topic_name: "Breadth-First & Depth-First Search",
              category: "weak",
              activity: "Timed quiz on connected components and bipartite graph detection.",
              duration_minutes: 50,
            },
          ],
        },
        {
          day: 5,
          theme: "Full Comprehensive Diagnostic & Readiness Check",
          allocated_hours: 3,
          tasks: [
            {
              topic_name: "Comprehensive Diagnostic",
              category: "weak",
              activity: "Retake full GapFinder diagnostic quiz covering all 5 topics.",
              duration_minutes: 60,
            },
            {
              topic_name: "Targeted Weak Point Remediation",
              category: "weak",
              activity: "Consult Grounded Assistant on any remaining erroneous concepts.",
              duration_minutes: 80,
            },
            {
              topic_name: "High-level Invariant Review",
              category: "strong",
              activity: "Quick review of Big-O complexity cheat sheet across all units.",
              duration_minutes: 40,
            },
          ],
        },
      ],
      created_at: now,
    });
  }
}

export const db = new Database();
