import { z } from "zod";

export const TopicTreeSchema = z.object({
  topics: z.array(
    z.object({
      name: z.string().describe("Topic name"),
      subtopics: z.array(z.string()).default([]),
    })
  ),
});

export const QuizQuestionsSchema = z.object({
  questions: z.array(
    z.object({
      topic_id: z.string().optional(),
      topic_name: z.string().optional(),
      question: z.string(),
      options: z.array(z.string()).min(2).max(4),
      correct_answer: z.string(),
      source_chunk_id: z.string().optional(),
      citation_quote: z.string().describe("Exact or near-exact short snippet from chunk"),
      explanation: z.string(),
    })
  ),
});

export const EvaluationSchema = z.object({
  is_correct: z.boolean(),
  explanation: z.string(),
  reference_quote: z.string().optional(),
});

export const GapReportSchema = z.object({
  topicGaps: z.array(
    z.object({
      topic_id: z.string(),
      topic_name: z.string(),
      score: z.number(),
      category: z.enum(["weak", "medium", "strong"]),
      reason: z.string(),
    })
  ),
});

export const RevisionPlanSchema = z.object({
  schedule: z.array(
    z.object({
      day: z.number(),
      theme: z.string(),
      allocated_hours: z.number(),
      tasks: z.array(
        z.object({
          topic_name: z.string(),
          category: z.enum(["weak", "medium", "strong"]),
          activity: z.string(),
          duration_minutes: z.number(),
        })
      ),
    })
  ),
});
